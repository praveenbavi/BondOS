# 🚀 BondOS Deployment Guide

Production deployment instructions for all three components.

---

## 📋 Pre-Deployment Checklist

- [ ] Update `SECRET_KEY` to a strong random value
- [ ] Set `DEBUG = False` in backend config
- [ ] Test all features locally
- [ ] Run `npm run build` for frontend
- [ ] Set up error logging (Sentry, LogRocket, etc.)
- [ ] Configure database backups
- [ ] Set up monitoring (Uptime Robot, etc.)

---

## 🖥️ Backend Deployment

### Option 1: Heroku

```bash
# 1. Create Heroku app
heroku create bonidos-api

# 2. Create Procfile
cat > Procfile << EOF
web: uvicorn app.main:app --host 0.0.0.0 --port $PORT
release: python -c "from app.database import init_db; import asyncio; asyncio.run(init_db())"
EOF

# 3. Set environment variables
heroku config:set SECRET_KEY="your-secret-key-here"
heroku config:set DEBUG=False
heroku config:set DATABASE_URL="postgresql://user:pass@host:5432/bonidos"  # Use Postgres for prod
heroku config:set CORS_ORIGINS='["https://bonidos.com", "https://app.bonidos.com"]'

# 4. Deploy
git push heroku main

# 5. View logs
heroku logs --tail
```

### Option 2: Railway.app

```bash
# 1. Install Railway CLI
npm i -g @railway/cli

# 2. Link project
railway link

# 3. Create PostgreSQL database
railway add --name database

# 4. Set environment variables
railway variables

# 5. Deploy
railway deploy

# 6. View URL
railway domain
```

### Option 3: AWS EC2

```bash
# 1. SSH into instance
ssh -i your-key.pem ec2-user@your-instance-ip

# 2. Install dependencies
sudo apt update
sudo apt install python3.10 python3-pip python3-venv

# 3. Clone repo
git clone https://github.com/yourusername/bonidos.git
cd bonidos/backend

# 4. Create venv and install
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 5. Install Gunicorn (production server)
pip install gunicorn

# 6. Run with Gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 "app.main:app" --access-logfile - --error-logfile -

# 7. Use systemd for auto-restart
sudo nano /etc/systemd/system/bonidos.service
```

**Systemd service file:**
```ini
[Unit]
Description=BondOS API
After=network.target

[Service]
User=ec2-user
WorkingDirectory=/home/ec2-user/bonidos/backend
ExecStart=/home/ec2-user/bonidos/backend/venv/bin/gunicorn -w 4 -b 0.0.0.0:8000 "app.main:app"
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl start bonidos
sudo systemctl enable bonidos
```

### Option 4: Docker

**Dockerfile:**
```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt gunicorn

COPY . .

EXPOSE 8000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:8000", "--timeout", "300", "app.main:app"]
```

**docker-compose.yml:**
```yaml
version: '3.8'
services:
  api:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      SECRET_KEY: ${SECRET_KEY}
      DEBUG: 'False'
      DATABASE_URL: postgresql://user:password@db:5432/bonidos
    depends_on:
      - db
  db:
    image: postgres:15
    environment:
      POSTGRES_USER: bonidos_user
      POSTGRES_PASSWORD: secure_password
      POSTGRES_DB: bonidos
    volumes:
      - postgres_data:/var/lib/postgresql/data
volumes:
  postgres_data:
```

```bash
docker-compose up -d
```

---

## 🎨 Frontend Deployment

### Option 1: Vercel

```bash
# 1. Push to GitHub
git push origin main

# 2. Connect Vercel to GitHub
# Go to vercel.com, click "Import Project"
# Select your repository

# 3. Configure build
# Framework: Vite
# Build Command: npm run build
# Output Directory: dist

# 4. Environment Variables
# VITE_API_URL=https://bonidos-api.herokuapp.com/api/v1
# VITE_WS_URL=wss://bonidos-api.herokuapp.com/ws

# 5. Deploy
# Automatic on git push
```

### Option 2: Netlify

```bash
# 1. Build locally
npm run build

# 2. Deploy to Netlify
npm install -g netlify-cli
netlify deploy --prod --dir=dist

# 3. Configure in netlify.toml
cat > netlify.toml << EOF
[build]
  command = "npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18.0.0"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "SAMEORIGIN"
    X-Content-Type-Options = "nosniff"
    X-XSS-Protection = "1; mode=block"
EOF

# 4. Push to deploy automatically
git push origin main
```

### Option 3: GitHub Pages

```bash
# 1. Update vite.config.js
export default {
  base: '/bonidos/',
  ...
}

# 2. Build
npm run build

# 3. Deploy
npm install --save-dev gh-pages
npm run build
npx gh-pages -d dist
```

### Option 4: Self-Hosted (nginx)

```bash
# 1. Build
npm run build

# 2. Install nginx
sudo apt install nginx

# 3. Configure nginx
sudo nano /etc/nginx/sites-available/bonidos
```

**Nginx config:**
```nginx
server {
    listen 80;
    server_name bonidos.com www.bonidos.com;
    
    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name bonidos.com www.bonidos.com;
    
    ssl_certificate /etc/letsencrypt/live/bonidos.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/bonidos.com/privkey.pem;
    
    root /var/www/bonidos;
    index index.html;
    
    # React Router fallback
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|webp)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # API proxy
    location /api/ {
        proxy_pass http://localhost:8000/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WebSocket proxy
    location /ws {
        proxy_pass http://localhost:8000/ws;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

```bash
# 4. Enable site
sudo ln -s /etc/nginx/sites-available/bonidos /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# 5. SSL Certificate (Let's Encrypt)
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d bonidos.com -d www.bonidos.com
```

---

## 📱 Mobile Deployment

### iOS App Store

```bash
# 1. Create EAS Build account
eas build --platform ios

# 2. Configure app.json
{
  "expo": {
    "name": "BondOS",
    "slug": "bonidos",
    "version": "1.0.0",
    "ios": {
      "bundleIdentifier": "com.bonidos.app"
    }
  }
}

# 3. Build
eas build --platform ios --auto-submit

# 4. App Store Connect
# Upload to TestFlight, then submit to App Store
```

### Google Play Store

```bash
# 1. Generate keystore
keytool -genkey-pair -v -keystore bonidos.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias bonidos

# 2. Configure eas.json
{
  "build": {
    "release": {
      "android": {
        "buildType": "apk"
      }
    }
  }
}

# 3. Build
eas build --platform android

# 4. Upload to Play Store via Play Console
```

---

## 🔒 Security Checklist

- [ ] Enable HTTPS (SSL/TLS) everywhere
- [ ] Use strong SECRET_KEY (minimum 32 characters)
- [ ] Set secure CORS origins (no *)
- [ ] Enable CSRF protection if using sessions
- [ ] Hash all passwords (bcrypt with 12+ rounds)
- [ ] Implement rate limiting on auth endpoints
- [ ] Use secure database password
- [ ] Enable database backups
- [ ] Monitor for security updates
- [ ] Implement DDoS protection (Cloudflare)
- [ ] Use environment variables for secrets
- [ ] Enable request logging and monitoring
- [ ] Regular security audits

---

## 📊 Monitoring & Logging

### Sentry (Error Tracking)

```python
# backend/app/main.py
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration

sentry_sdk.init(
    dsn="https://your-sentry-dsn@sentry.io/...",
    integrations=[FastApiIntegration()],
    traces_sample_rate=0.1,
)
```

### LogRocket (Frontend)

```javascript
// frontend/src/main.jsx
import LogRocket from 'logrocket'

LogRocket.init('your-app-id')
```

### Uptime Robot

```
Create monitor:
- URL: https://api.bonidos.com/health
- Check interval: 5 minutes
- Alert via email/SMS
```

---

## 🔄 CI/CD Pipeline

### GitHub Actions

**`.github/workflows/deploy.yml`:**
```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  test-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - run: pip install -r backend/requirements.txt
      - run: pytest backend/tests

  test-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: cd frontend && npm install && npm run build

  deploy:
    needs: [test-backend, test-frontend]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: git push https://heroku:${{ secrets.HEROKU_AUTH_TOKEN }}@git.heroku.com/bonidos-api.git main
      - run: |
          curl -X POST https://api.vercel.com/v13/deployments \
            -H "Authorization: Bearer ${{ secrets.VERCEL_TOKEN }}" \
            -d '{"name":"bonidos","gitSource":{"type":"github","repo":"yourusername/bonidos","ref":"main"}}'
```

---

## 📈 Performance Optimization

### Backend
- Enable gzip compression
- Use CDN for static assets
- Cache database queries
- Use connection pooling
- Enable query optimization

### Frontend
- Lazy load routes
- Code split with React.lazy
- Tree-shake unused code
- Minify CSS/JS
- Use WebP for images
- Implement service workers

### Database
- Add indexes on frequently queried columns
- Regular VACUUM and ANALYZE
- Use connection pooling
- Archive old data

---

## 🔄 Update Strategy

```bash
# 1. Tag release
git tag -a v1.1.0 -m "Release 1.1.0"
git push origin v1.1.0

# 2. Create release notes
# Go to GitHub > Releases > Create release

# 3. Monitor for issues
# Watch error tracking, user reports

# 4. Rollback if needed
git revert <commit-hash>
git push origin main
```

---

## 📞 Support & Troubleshooting

### Heroku Logs
```bash
heroku logs --tail
```

### SSH into EC2
```bash
ssh -i key.pem ec2-user@ip
tail -f /var/log/syslog
```

### Docker Logs
```bash
docker logs -f container_name
```

### Database Backups
```bash
# Heroku
heroku pg:backups:capture

# AWS RDS
aws rds create-db-snapshot --db-instance-identifier bonidos --db-snapshot-identifier bonidos-backup-$(date +%s)
```

---

**Deployment complete! 🎉**

Monitor your app at:
- API: https://api.bonidos.com/health
- Web: https://bonidos.com
- Docs: https://api.bonidos.com/docs
