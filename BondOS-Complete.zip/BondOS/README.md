# 🔗 BondOS – Complete Project Documentation

**Version:** 1.0.0  
**Status:** Production-Ready  
**Architecture:** Python FastAPI Backend + React Web Frontend + React Native Mobile App

---

## 📋 Project Overview

BondOS is an enterprise-grade **Relationship Operating System** built with modern technologies. It enables emotionally intelligent human connections through:

- ✅ **Approval-based reminders** (soft, alarm, persistent types)
- ✅ **Real-time messaging** with WebSocket support
- ✅ **Mood tracking** with pulse analytics
- ✅ **Moments sharing** (photos, videos, stories)
- ✅ **Anonymous posts** with reactions
- ✅ **Live location sharing** with safe zones
- ✅ **Shared goals** with streak tracking
- ✅ **Group chats** with rich media support
- ✅ **Delayed messages** (unlock at specific time)
- ✅ **Quiet mode** for mental health breaks

---

## 🏗️ Architecture

### **Backend Stack**
```
Framework:     FastAPI 0.115.0 (async Python)
Database:      SQLite in-memory (H2-equivalent)
ORM:           SQLAlchemy 2.0 (async)
Auth:          JWT + bcrypt
Real-time:     WebSockets
```

### **Frontend Stack (Web)**
```
Framework:     React 18.3 + React Router 6
State:         Redux Toolkit + React Redux
Styling:       Tailwind CSS 3.4 + custom animations
Build:         Vite 5.4
HTTP Client:   Axios with interceptors
Animations:    Framer Motion
UI:            Custom components + Lucide Icons
```

### **Mobile Stack**
```
Framework:     React Native (Expo 50)
Navigation:    React Navigation 6
State:         Redux Toolkit
Styling:       StyleSheet
HTTP:          Axios
```

---

## 📁 Project Structure

```
BondOS/
├── backend/
│   ├── app/
│   │   ├── core/                    # Core configs, security, dependencies
│   │   │   ├── config.py            # Settings from env
│   │   │   ├── security.py          # JWT, bcrypt, hashing
│   │   │   ├── dependencies.py      # FastAPI deps (DB, auth, pagination)
│   │   │   └── __init__.py
│   │   ├── models/                  # SQLAlchemy ORM models
│   │   │   ├── user.py              # User with moods, reminders, posts
│   │   │   ├── connection.py        # User relationships (bestie, family, etc)
│   │   │   ├── reminder.py          # Approval-based reminders
│   │   │   ├── message.py           # 1:1 & group chat, delayed messages
│   │   │   ├── post.py              # Moments (photos, videos, stories)
│   │   │   ├── mood.py              # Mood tracking with visibility
│   │   │   ├── location.py          # Live location + safe zones
│   │   │   ├── anonymous.py         # Anonymous posts & reactions
│   │   │   ├── goal.py              # Shared goals with streaks
│   │   │   └── __init__.py
│   │   ├── schemas/                 # Pydantic request/response models
│   │   │   ├── user.py              # User schemas
│   │   │   └── __init__.py          # All other schemas
│   │   ├── services/                # Business logic layer
│   │   │   ├── auth_service.py      # Register, login, JWT
│   │   │   ├── user_service.py      # User CRUD, search
│   │   │   ├── reminder_service.py  # Reminder approval flow
│   │   │   ├── message_service.py   # Chat, mark read, conversations
│   │   │   ├── mood_service.py      # Mood CRUD + Pulse analytics
│   │   │   ├── connection_service.py # Connections, acceptance
│   │   │   └── __init__.py
│   │   ├── routers/                 # FastAPI route handlers
│   │   │   ├── auth.py              # /auth/* endpoints
│   │   │   └── __init__.py          # All feature routers (reminders, messages, etc)
│   │   ├── database.py              # SQLAlchemy engine, session, lifecycle
│   │   └── main.py                  # FastAPI app, CORS, WebSocket, lifespan
│   ├── seed/
│   │   └── seed.sql                 # Initial test data (6 users, connections, etc)
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── store/
│   │   │   ├── slices/
│   │   │   │   ├── authSlice.js     # Auth state (user, token, login)
│   │   │   │   └── dataSlice.js     # App state (connections, messages, etc)
│   │   │   └── store.js             # Redux store config
│   │   ├── services/
│   │   │   ├── api.js               # Axios instance + interceptors
│   │   │   ├── index.js             # All API services (auth, reminders, etc)
│   │   │   └── websocketService.js  # WebSocket client with heartbeat
│   │   ├── hooks/
│   │   │   └── index.js             # useAuth, useConnections, useMessages, etc
│   │   ├── components/
│   │   │   ├── common/
│   │   │   │   └── index.jsx        # Layout, BottomNav, Button, Card, etc
│   │   │   ├── dashboard/
│   │   │   │   └── index.jsx        # Home page with people & reminders
│   │   │   ├── chat/
│   │   │   │   └── index.jsx        # ChatList & ChatDetail
│   │   │   ├── pulse/
│   │   │   │   └── index.jsx        # Mood health analytics
│   │   │   ├── moments/
│   │   │   │   └── index.jsx        # Moments & Anonymous posts
│   │   │   └── reminders/
│   │   │       └── index.jsx        # Reminder approval UI
│   │   ├── pages/
│   │   │   ├── Auth.jsx             # Login & Register pages
│   │   │   └── Settings.jsx         # User settings & mood selector
│   │   ├── utils/                   # Helpers (date formatting, validation)
│   │   ├── index.css                # Global CSS + design tokens
│   │   ├── App.jsx                  # React Router setup
│   │   └── main.jsx                 # React entry point
│   ├── public/                      # Static assets
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   ├── package.json
│   └── postcss.config.js
├── mobile/
│   ├── src/
│   │   ├── store/                   # Redux (same as web)
│   │   ├── services/                # API services
│   │   ├── hooks/                   # Custom hooks
│   │   ├── navigation/
│   │   │   └── index.js             # React Navigation setup
│   │   ├── screens/
│   │   │   ├── auth/
│   │   │   │   └── LoginScreen.js   # Login & Register
│   │   │   ├── index.js             # Dashboard, Chat, Pulse, etc screens
│   │   │   └── settings/
│   │   └── utils/
│   ├── App.js                       # Root component with Redux Provider
│   ├── package.json
│   └── app.json                     # Expo config
└── README.md
```

---

## 🚀 Quick Start

### **Prerequisites**
- Python 3.10+
- Node.js 18+
- npm or yarn
- Git

### **Backend Setup**

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the server (dev mode)
uvicorn app.main:app --reload --port 8000

# Server will be available at http://localhost:8000
# API docs at http://localhost:8000/docs
```

### **Frontend Web Setup**

```bash
cd frontend

# Install dependencies
npm install

# Start dev server
npm run dev

# Navigate to http://localhost:5173
```

### **Mobile Setup**

```bash
cd mobile

# Install dependencies
npm install

# Start Expo
npm start

# Press 'i' for iOS or 'a' for Android
```

---

## 🔑 Key Features & Implementation

### **1. Approval-Based Reminders**
- User A sends reminder to User B
- User B sees it in "Pending" tab
- B can **Approve** → becomes "Active"
- B can **Reject** → marked as "Rejected"
- Multiple reminder types: soft, alarm, persistent
- Repeat options: daily, weekly, custom

**Endpoints:**
```
POST   /api/v1/reminders              # Send reminder
POST   /api/v1/reminders/{id}/approve # Approve
POST   /api/v1/reminders/{id}/reject  # Reject
GET    /api/v1/reminders/active       # Active reminders
```

### **2. Real-Time Messaging**
- 1:1 chat with message history
- Group chats
- Delayed messages (unlock at specific time)
- Voice notes, media attachments
- Real-time updates via WebSocket
- Auto-mark as read

**Key Services:**
```python
MessageService.send()              # Send message
MessageService.get_conversation()  # Chat history
MessageService.unlock_delayed()    # Periodic task to unlock delayed messages
```

### **3. Mood & Pulse System**
- User sets mood with emoji
- Visibility control (close_circle, family, all)
- Pulse aggregates connection moods
- "Needs Support" detection

**Flow:**
```
User sets mood → triggers "is_support_triggered" flag
→ Pulse shows "needs_support" count
→ Suggests outreach messages
```

### **4. Anonymous Posts**
- Circle-based anonymity (all, close_circle, family)
- Author ID hidden from receivers
- Reactions with emoji
- Kept for moderation purposes

### **5. Connections System**
- Bidirectional relationships
- Types: bestie, close_circle, family, friend
- Request → Accept/Reject flow
- Last interaction tracking

---

## 📊 Database Schema (Key Tables)

```sql
users
├── id (PK)
├── name, username, email (unique)
├── hashed_password
├── mood, mood_emoji, is_quiet_mode
├── location_sharing
└── created_at, updated_at

connections
├── id (PK)
├── user_id, connected_user_id (FK)
├── connection_type (enum)
├── status (pending|accepted|blocked)
├── last_interaction
└── created_at

reminders
├── id (PK)
├── sender_id, receiver_id (FK)
├── message, reminder_type (soft|alarm|persistent)
├── status (pending|approved|rejected|active|completed)
├── remind_at, repeat_type
├── priority (low|normal|high)
└── created_at

messages
├── id (PK)
├── sender_id, receiver_id, group_id (FK)
├── content, media_url, message_type
├── is_read, is_deleted
├── unlock_at, is_unlocked (for delayed messages)
└── created_at

moods
├── id (PK)
├── user_id (FK)
├── mood, emoji, note
├── visible_to, is_support_triggered
└── created_at

posts
├── id (PK)
├── user_id (FK)
├── caption, media_url, media_type
├── visibility (close_circle|family|all|private)
├── is_story, expires_at
└── created_at
```

---

## 🔐 Authentication & Security

### **JWT Implementation**
```python
# In core/security.py
create_access_token(user_id)        # Creates signed JWT
decode_access_token(token)          # Verifies & decodes
extract_user_id(token)              # Gets user_id from token
```

### **Password Hashing**
```python
hash_password(plaintext)            # Bcrypt hash
verify_password(plaintext, hashed)  # Verify
```

### **Protected Routes**
```python
# All protected endpoints use:
@router.get("/...")
async def endpoint(
    db: AsyncSession = Depends(get_db),
    user_id: int = Depends(get_current_user_id),  # Validates JWT
):
    ...
```

---

## 🌐 WebSocket Usage

### **Client Connection**
```javascript
// Frontend
const wsService = new WebSocketService()
wsService.connect(token)

wsService.on('new_message', (data) => {
  // Handle incoming message
})

wsService.send('typing', { to: partnerId })
```

### **Server Events**
```python
# Server broadcasts to specific user or all users
await ws_manager.send_to_user(user_id, "new_message", data)
await ws_manager.broadcast("presence", { user_id, online: true })
```

---

## 🧪 Testing

### **Seed Data**
The application loads seed data automatically on startup:

```bash
# 6 test users created with:
# - Email: user@bonidos.app (password: password123)
# - Pre-made connections
# - Sample reminders, messages, moods
```

**Test Users:**
- aviral_07 (Aviral Sharma)
- ananya_p (Ananya Patel)
- rohan_m (Rohan Mehta)
- priya_s (Priya Singh)
- dev_k (Dev Kapoor)
- meera_n (Meera Nair)

### **API Testing**
```bash
# Using curl or Postman
POST http://localhost:8000/api/v1/auth/login
{
  "email": "aviral@bonidos.app",
  "password": "password123"
}

# Returns: { access_token, token_type, user }
# Use token in Authorization header: Bearer <token>
```

---

## 📈 Performance & Optimization

### **Database**
- In-memory SQLite with StaticPool for async consistency
- Indexed queries on user_id, status, timestamps
- Async/await for non-blocking I/O

### **Frontend**
- Code splitting with React.lazy()
- Redux memoization prevents unnecessary re-renders
- Framer Motion for GPU-accelerated animations
- Tailwind CSS purged for production (~15KB gzip)

### **Backend**
- Pagination on all list endpoints (default 20, max 100)
- WebSocket connection pooling
- JWT token expiry: 7 days
- Bcrypt rounds: 12

---

## 🎨 Design System

### **Color Palette**
```css
--bond-primary:  #6477f8  (Lavender Blue)
--bond-surface:  #ffffff  (White)
--bond-bg:       #f7f8fc  (Light Gray)
--bond-text:     #1a1d2e  (Dark)
--bond-muted:    #6b7280  (Gray)
```

### **Typography**
- Display: Sora (bold headings)
- Body: Plus Jakarta Sans (readable, friendly)
- Monospace: System (data)

### **Spacing & Radius**
- 4px, 8px, 12px, 16px, 24px
- Rounded: 10px (small), 16px (medium), 24px (button)

---

## 📚 Code Quality Standards

### **Python Backend**
- Type hints on all functions
- Docstrings for classes & modules
- PEP 8 compliant
- SQLAlchemy mapped_column pattern
- Async/await throughout

### **React Frontend**
- Functional components with Hooks
- Redux RTK for state management
- Tailwind utility-first CSS
- Framer Motion for animations
- Error boundaries on page routes

### **React Native**
- React Native best practices
- StyleSheet for performance
- AsyncStorage for persistence
- Redux for state consistency

---

## 🔄 API Rate Limits & Throttling

Currently not implemented; add as needed:
```python
# Example: 100 requests per minute per user
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.post("/api/v1/messages")
@limiter.limit("100/minute")
async def send_message(...):
    ...
```

---

## 🚨 Error Handling

### **Standard HTTP Responses**
```json
200 OK              { "data": ... }
201 Created         { "data": ... }
400 Bad Request     { "detail": "Validation failed" }
401 Unauthorized    { "detail": "Could not validate credentials" }
404 Not Found       { "detail": "User not found" }
409 Conflict        { "detail": "Email already taken" }
500 Server Error    { "detail": "Internal server error" }
```

### **Frontend Toast Notifications**
```javascript
toast.success("Action completed!")
toast.error("Something went wrong")
toast.loading("Processing...")
```

---

## 📱 Mobile App Configuration

### **Expo Setup** (`app.json`)
```json
{
  "expo": {
    "name": "BondOS",
    "slug": "bonidos",
    "version": "1.0.0",
    "assetBundlePatterns": ["**/*"],
    "ios": { "supportsTabletMode": true },
    "android": { "adaptiveIcon": { "foregroundImage": "./assets/adaptive-icon.png" } }
  }
}
```

---

## 🚀 Deployment

### **Backend (Heroku/Railway)**
```bash
# Create Procfile
web: uvicorn app.main:app --host 0.0.0.0 --port $PORT

# Environment variables
SECRET_KEY
DATABASE_URL
CORS_ORIGINS
```

### **Frontend (Vercel/Netlify)**
```bash
npm run build
# Outputs to dist/
# Configure redirects for React Router
```

### **Mobile (EAS Build)**
```bash
eas build --platform ios
eas build --platform android
```

---

## 📞 Support & Contributing

For issues, feature requests, or contributions:
1. Create an issue on GitHub
2. Fork & create a feature branch
3. Submit a pull request

---

## 📄 License

MIT License – See LICENSE file

---

## 🎯 Roadmap

- [ ] AI suggestions for when to message
- [ ] Wearable integration (Apple Health, Fitbit)
- [ ] Voice AI (Whisper API)
- [ ] Smart reminders based on location
- [ ] Relationship milestones tracking
- [ ] Family tree/circle visualization
- [ ] Encryption for sensitive messages
- [ ] 2FA authentication
- [ ] Analytics dashboard

---

**Built with 💙 for human connection**

BondOS Team | 2024
