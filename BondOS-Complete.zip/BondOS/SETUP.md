# 🔧 BondOS Setup Guide

Complete step-by-step setup for development environment.

---

## ⚙️ Backend Setup

### Step 1: Environment

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate it
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Verify Python version (3.10+)
python --version
```

### Step 2: Dependencies

```bash
pip install -r requirements.txt

# You should see installations of:
# - fastapi, uvicorn
# - sqlalchemy, aiosqlite
# - pydantic, pydantic-settings
# - python-jose, passlib, bcrypt
# - python-multipart, httpx
```

### Step 3: Run Server

```bash
# Development mode with auto-reload
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# You should see:
# INFO:     Application startup complete
# INFO:     Uvicorn running on http://0.0.0.0:8000
```

### Step 4: Verify

```bash
# In another terminal, test health endpoint
curl http://localhost:8000/health
# Response: {"status":"ok","version":"1.0.0"}

# View API docs
open http://localhost:8000/docs  # macOS
# or go to http://localhost:8000/docs in browser
```

### Step 5: Seed Data

Data loads automatically on startup. Test with seed users:

```bash
# POST http://localhost:8000/api/v1/auth/login
{
  "email": "aviral@bonidos.app",
  "password": "password123"
}

# Should return JWT token and user data
```

---

## 🎨 Frontend Web Setup

### Step 1: Install Dependencies

```bash
cd frontend

npm install
# or
yarn install
```

### Step 2: Configure Environment

Create `.env.local`:

```env
VITE_API_URL=http://localhost:8000/api/v1
VITE_WS_URL=ws://localhost:8000/ws
```

### Step 3: Start Dev Server

```bash
npm run dev

# You should see:
# ➜  Local:   http://localhost:5173/
# ➜  press h to show help
```

### Step 4: Access App

```
http://localhost:5173/
```

Navigate to login, use seed credentials:
- Email: `aviral@bonidos.app`
- Password: `password123`

### Step 5: Build for Production

```bash
npm run build

# Outputs optimized build to dist/
# Ready for deployment to Vercel, Netlify, etc.
```

---

## 📱 Mobile App Setup

### Step 1: Prerequisites

```bash
# Install Expo CLI globally
npm install -g expo-cli

# Verify installation
expo --version
```

### Step 2: Install Dependencies

```bash
cd mobile

npm install
```

### Step 3: Configure API URL

Create `src/utils/config.js`:

```javascript
export const API_BASE_URL = 'http://10.0.2.2:8000/api/v1'  // Android emulator
export const WS_URL = 'ws://10.0.2.2:8000/ws'

// For physical device, use your computer's LAN IP:
// export const API_BASE_URL = 'http://192.168.x.x:8000/api/v1'
```

### Step 4: Start Expo

```bash
npm start

# or
expo start
```

You'll see a QR code in terminal.

### Step 5: Run on Device/Emulator

**iOS:**
```bash
# Press 'i' in terminal, or:
expo run:ios
```

**Android:**
```bash
# Press 'a' in terminal, or:
expo run:android
# Make sure Android emulator is running first
```

**Physical Device:**
1. Install Expo Go app from App Store/Play Store
2. Scan QR code shown in terminal

---

## 🔄 Local Development Workflow

### Terminal 1: Backend
```bash
cd backend
source venv/bin/activate  # or venv\Scripts\activate on Windows
uvicorn app.main:app --reload --port 8000
```

### Terminal 2: Frontend Web
```bash
cd frontend
npm run dev
```

### Terminal 3 (Optional): Mobile
```bash
cd mobile
npm start
```

All three apps should now communicate with the same backend.

---

## 🧪 Testing the App

### 1. Register New User

**Frontend Web:**
1. Go to http://localhost:5173/register
2. Fill in form
3. Click "Create Account"

**Mobile:**
1. Tap "Create Account"
2. Fill in form
3. Submit

### 2. Add a Connection

1. Go to Dashboard
2. Click "+" button or "Add a friend"
3. Search for another user (e.g., "ananya_p")
4. Click to add

### 3. Send a Reminder

1. Find a connection
2. Click their card
3. Go to Reminders tab
4. Send reminder with custom message
5. Other user approves/rejects

### 4. Real-Time Chat

1. Find a connection
2. Click to open chat
3. Type and send message
4. See it appear in real-time

### 5. Set Mood

1. Go to Settings
2. Click mood emoji button
3. Select a mood
4. Check Pulse to see connections' moods

---

## 🔐 Authentication Flow

### Backend

```python
# 1. User registers
POST /api/v1/auth/register
{
  "name": "John",
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securepass123"
}

# Returns: { access_token, token_type: "bearer", user: {...} }

# 2. User logs in
POST /api/v1/auth/login
{
  "email": "john@example.com",
  "password": "securepass123"
}

# 3. Token stored in localStorage (web) / AsyncStorage (mobile)

# 4. All subsequent requests include:
# Authorization: Bearer <token>

# 5. If token expires (7 days), user redirected to login
```

### Frontend

```javascript
// axios interceptor auto-attaches token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('bonidos_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// auto-logout on 401
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('bonidos_token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)
```

---

## 🛠️ Common Issues & Troubleshooting

### Backend Won't Start

**Error:** `ModuleNotFoundError: No module named 'fastapi'`

**Solution:**
```bash
# Make sure virtual env is activated
source venv/bin/activate
# Then reinstall
pip install -r requirements.txt
```

### Frontend Can't Connect to Backend

**Error:** `CORS error` or `Cannot reach http://localhost:8000`

**Solution:**
1. Check backend is running on port 8000
2. Check CORS_ORIGINS in backend config includes `http://localhost:5173`
3. Check `.env.local` has correct API URL

### Database Locked Error

**Error:** `database is locked`

**Solution:**
- This is rare with SQLite in-memory
- If using file-based SQLite, close other connections
- Delete `*.db` file and restart

### Mobile Can't Connect to Backend

**Error:** `Network request failed` on device

**Solution:**
1. Find your computer's LAN IP: `ipconfig getifaddr en0` (macOS)
2. Update API_BASE_URL to use your IP, not localhost
3. Example: `http://192.168.1.100:8000/api/v1`

### WebSocket Connection Failed

**Error:** `WebSocket connection failed`

**Solution:**
1. Check backend WebSocket is enabled
2. Check firewall allows port 8000
3. Try connecting directly: `ws://localhost:8000/ws?token=...`

---

## 📊 Database Management

### View Seed Data

```bash
# Connect to in-memory database (harder)
# OR use SQL queries in code to inspect

# Python script to inspect:
python << 'EOF'
import asyncio
from app.database import AsyncSessionLocal
from app.models import User
from sqlalchemy import select

async def inspect():
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(User))
        users = result.scalars().all()
        for user in users:
            print(f"{user.id}: {user.name} ({user.username})")

asyncio.run(inspect())
EOF
```

### Reset Database

```bash
# Since we use in-memory DB, just restart backend
# All data is lost on restart (good for testing)

# To persist data, change DATABASE_URL in config.py:
DATABASE_URL=sqlite+aiosqlite:///./bonidos.db
```

---

## 📦 Dependency Versions

To ensure compatibility, lock your versions:

**Backend:**
```bash
pip freeze > requirements.txt
# Commit this to git
```

**Frontend:**
```bash
npm install --save-dev
# package-lock.json automatically committed
```

**Mobile:**
```bash
npm install
# package-lock.json automatically committed
```

---

## 🔗 Useful Links

- **FastAPI Docs:** http://localhost:8000/docs
- **FastAPI ReDoc:** http://localhost:8000/redoc
- **Vite DevTools:** Browser console (client-side only)
- **Redux DevTools:** Install browser extension for time-travel debugging
- **Tailwind IntelliSense:** Install VS Code extension

---

## ✅ Setup Checklist

- [ ] Python 3.10+ installed
- [ ] Node.js 18+ installed
- [ ] Backend venv created and activated
- [ ] All dependencies installed (pip + npm)
- [ ] Backend running on port 8000
- [ ] Frontend running on port 5173
- [ ] Can login with seed user (aviral@bonidos.app / password123)
- [ ] Can see Dashboard with connections
- [ ] Can send a test message
- [ ] Can set mood and see Pulse update

---

## 🚀 Next Steps

1. Read the main [README.md](../README.md) for architecture overview
2. Explore API documentation at /docs
3. Review component structure in frontend/src
4. Check backend service layer for business logic
5. Deploy to production (see DEPLOYMENT.md)

Happy coding! 💙
