"""
BondOS – Core Configuration
Centralised settings loaded from environment variables with sensible defaults.
"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────────────────────────
    APP_NAME: str = "BondOS"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # ── Security ─────────────────────────────────────────────────────────────
    SECRET_KEY: str = "bonidos-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # ── Database ─────────────────────────────────────────────────────────────
    # SQLite in-memory (Python equivalent of H2 in-memory)
    DATABASE_URL: str = "sqlite+aiosqlite:///:memory:"
    SEED_FILE: str = "seed/seed.sql"

    # ── CORS ─────────────────────────────────────────────────────────────────
    CORS_ORIGINS: list[str] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://localhost:19006",  # Expo
    ]

    # ── WebSocket ────────────────────────────────────────────────────────────
    WS_HEARTBEAT_INTERVAL: int = 30

    # ── Pagination ───────────────────────────────────────────────────────────
    DEFAULT_PAGE_SIZE: int = 20
    MAX_PAGE_SIZE: int = 100

    # ── Feature flags ────────────────────────────────────────────────────────
    ENABLE_ANONYMOUS: bool = True
    ENABLE_LOCATION: bool = True
    ENABLE_AI_SUGGESTIONS: bool = True

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Singleton settings – cached after first call."""
    return Settings()


settings = get_settings()
