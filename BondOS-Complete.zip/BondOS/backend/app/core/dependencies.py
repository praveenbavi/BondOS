"""
BondOS – FastAPI Dependencies
Reusable dependencies injected via Depends().
"""
from typing import AsyncGenerator

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import decode_access_token
from app.database import AsyncSessionLocal

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


# ── DB session ────────────────────────────────────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Yield an async SQLAlchemy session, roll back on error."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── Current user ──────────────────────────────────────────────────────────────
async def get_current_user_id(
    token: str = Depends(oauth2_scheme),
) -> int:
    """Extract and validate user ID from Bearer JWT."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    try:
        user_id = int(payload["sub"])
    except (KeyError, ValueError):
        raise credentials_exception
    return user_id


# ── Pagination ────────────────────────────────────────────────────────────────
def pagination_params(skip: int = 0, limit: int = 20) -> dict:
    """Standard pagination query params."""
    return {"skip": max(0, skip), "limit": min(limit, 100)}
