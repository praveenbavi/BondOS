"""
BondOS – Database Engine
Async SQLAlchemy with SQLite in-memory (H2-equivalent for Python).
Seeds initial data from seed/seed.sql on startup.
"""
import os
import logging
from pathlib import Path

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import text, event
from sqlalchemy.pool import StaticPool

from app.core.config import settings

logger = logging.getLogger(__name__)


# ── Base declarative class ────────────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── Engine ────────────────────────────────────────────────────────────────────
def _make_engine() -> AsyncEngine:
    """
    Create the async engine.
    For SQLite in-memory we need StaticPool so the same connection
    is reused across async calls (otherwise each connection gets its own DB).
    """
    return create_async_engine(
        settings.DATABASE_URL,
        echo=settings.DEBUG,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )


engine: AsyncEngine = _make_engine()

# ── Session factory ───────────────────────────────────────────────────────────
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


# ── Lifecycle helpers ─────────────────────────────────────────────────────────
async def create_all_tables() -> None:
    """Create all ORM-mapped tables (DDL)."""
    # Import all models so metadata is populated before create_all
    import app.models  # noqa: F401

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ All tables created")


async def load_seed_data() -> None:
    """Execute seed/seed.sql to populate initial data."""
    seed_path = Path(__file__).parent.parent / settings.SEED_FILE
    if not seed_path.exists():
        logger.warning("⚠️  Seed file not found: %s", seed_path)
        return

    sql_text = seed_path.read_text(encoding="utf-8")

    # Split statements by semicolon, execute each
    statements = [s.strip() for s in sql_text.split(";") if s.strip()]
    async with AsyncSessionLocal() as session:
        for stmt in statements:
            try:
                await session.execute(text(stmt))
            except Exception as exc:  # noqa: BLE001
                logger.warning("Seed stmt skipped (%s): %.120s", exc, stmt)
        await session.commit()
    logger.info("✅ Seed data loaded (%d statements)", len(statements))


async def init_db() -> None:
    """Full DB initialisation: DDL + seed."""
    await create_all_tables()
    await load_seed_data()


async def close_db() -> None:
    """Dispose the engine on shutdown."""
    await engine.dispose()
    logger.info("✅ DB engine disposed")
