"""
BondOS – FastAPI Application Entry Point
Registers all routers, WebSocket hub, CORS, lifespan, and OpenAPI metadata.
"""
import asyncio
import json
import logging
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.security import decode_access_token
from app.database import init_db, close_db
from app.routers import (
    users_router,
    connections_router,
    reminders_router,
    messages_router,
    moods_router,
    pulse_router,
    anonymous_router,
)
from app.routers.auth import router as auth_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bonidos")


# ── WebSocket Connection Manager ──────────────────────────────────────────────
class ConnectionManager:
    """Manages active WebSocket connections, keyed by user_id."""

    def __init__(self):
        self._connections: dict[int, list[WebSocket]] = {}

    async def connect(self, user_id: int, ws: WebSocket) -> None:
        await ws.accept()
        self._connections.setdefault(user_id, []).append(ws)
        logger.info("WS connected: user %d (total sockets: %d)", user_id, len(ws.__class__.__dict__))

    def disconnect(self, user_id: int, ws: WebSocket) -> None:
        sockets = self._connections.get(user_id, [])
        if ws in sockets:
            sockets.remove(ws)
        if not sockets:
            self._connections.pop(user_id, None)

    async def send_to_user(self, user_id: int, event: str, data: dict) -> None:
        payload = json.dumps({"event": event, "data": data})
        for ws in self._connections.get(user_id, []):
            try:
                await ws.send_text(payload)
            except Exception:
                pass

    async def broadcast(self, event: str, data: dict) -> None:
        payload = json.dumps({"event": event, "data": data})
        for sockets in self._connections.values():
            for ws in sockets:
                try:
                    await ws.send_text(payload)
                except Exception:
                    pass

    @property
    def online_user_ids(self) -> list[int]:
        return list(self._connections.keys())


ws_manager = ConnectionManager()


# ── App Lifespan ──────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 BondOS starting up…")
    await init_db()
    yield
    logger.info("🔴 BondOS shutting down…")
    await close_db()


# ── FastAPI Instance ──────────────────────────────────────────────────────────
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Relationship Operating System – API",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── API Routers ───────────────────────────────────────────────────────────────
API_PREFIX = "/api/v1"

app.include_router(auth_router, prefix=API_PREFIX)
app.include_router(users_router, prefix=API_PREFIX)
app.include_router(connections_router, prefix=API_PREFIX)
app.include_router(reminders_router, prefix=API_PREFIX)
app.include_router(messages_router, prefix=API_PREFIX)
app.include_router(moods_router, prefix=API_PREFIX)
app.include_router(pulse_router, prefix=API_PREFIX)
app.include_router(anonymous_router, prefix=API_PREFIX)


# ── WebSocket Endpoint ────────────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(
    ws: WebSocket,
    token: Optional[str] = Query(default=None),
):
    """
    Real-time WebSocket connection.
    Client connects with: ws://localhost:8000/ws?token=<jwt>
    """
    if not token:
        await ws.close(code=4001, reason="Missing token")
        return

    payload = decode_access_token(token)
    if not payload:
        await ws.close(code=4003, reason="Invalid token")
        return

    user_id = int(payload["sub"])
    await ws_manager.connect(user_id, ws)

    # Notify others that this user is online
    await ws_manager.broadcast("presence", {"user_id": user_id, "online": True})

    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
                event = msg.get("event", "")
                data = msg.get("data", {})

                if event == "ping":
                    await ws.send_text(json.dumps({"event": "pong"}))

                elif event == "typing":
                    target_id = data.get("to")
                    if target_id:
                        await ws_manager.send_to_user(
                            target_id, "typing", {"from": user_id}
                        )

                elif event == "new_message":
                    target_id = data.get("to")
                    if target_id:
                        await ws_manager.send_to_user(
                            target_id, "new_message", {**data, "from": user_id}
                        )

                elif event == "reminder_approved":
                    sender_id = data.get("sender_id")
                    if sender_id:
                        await ws_manager.send_to_user(
                            sender_id, "reminder_approved", data
                        )

                elif event == "mood_update":
                    await ws_manager.broadcast("mood_update", {**data, "user_id": user_id})

            except json.JSONDecodeError:
                pass

    except WebSocketDisconnect:
        ws_manager.disconnect(user_id, ws)
        await ws_manager.broadcast("presence", {"user_id": user_id, "online": False})


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    return JSONResponse({"status": "ok", "version": settings.APP_VERSION})


@app.get("/")
async def root():
    return {"message": f"Welcome to {settings.APP_NAME} API", "docs": "/docs"}
