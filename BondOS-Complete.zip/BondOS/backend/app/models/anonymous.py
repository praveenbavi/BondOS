"""BondOS – Anonymous Post Model"""
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class AnonymousPost(Base):
    __tablename__ = "anonymous_posts"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    # author_id is hidden from receivers – kept for moderation only
    author_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    content: Mapped[str] = mapped_column(Text, nullable=False)
    # Circle-based anonymous mode: which circle can see this
    visible_to_circle: Mapped[str] = mapped_column(String(30), default="all")
    reaction_count: Mapped[int] = mapped_column(Integer, default=0)
    comment_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    reactions: Mapped[list["AnonymousReaction"]] = relationship(
        back_populates="post", cascade="all, delete-orphan"
    )
    compliments: Mapped[list["SecretCompliment"]] = relationship(
        back_populates="post", cascade="all, delete-orphan"
    )


class AnonymousReaction(Base):
    __tablename__ = "anonymous_reactions"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    post_id: Mapped[int] = mapped_column(ForeignKey("anonymous_posts.id"), nullable=False)
    reactor_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))  # hidden
    emoji: Mapped[str] = mapped_column(String(10), default="❤️")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    post: Mapped["AnonymousPost"] = relationship(back_populates="reactions")


class SecretCompliment(Base):
    __tablename__ = "secret_compliments"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    post_id: Mapped[int] = mapped_column(ForeignKey("anonymous_posts.id"), nullable=False)
    sender_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))  # hidden
    content: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    post: Mapped["AnonymousPost"] = relationship(back_populates="compliments")
