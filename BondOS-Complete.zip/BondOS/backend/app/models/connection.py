"""BondOS – Connection Model (relationships between users)"""
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Enum, ForeignKey, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum

from app.database import Base


class ConnectionType(str, enum.Enum):
    CLOSE_CIRCLE = "close_circle"
    FAMILY = "family"
    BESTIE = "bestie"
    FRIEND = "friend"


class ConnectionStatus(str, enum.Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    BLOCKED = "blocked"


class Connection(Base):
    __tablename__ = "connections"
    __table_args__ = (
        UniqueConstraint("user_id", "connected_user_id", name="uq_connection"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    connected_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    connection_type: Mapped[str] = mapped_column(
        String(30), default=ConnectionType.FRIEND.value
    )
    status: Mapped[str] = mapped_column(
        String(20), default=ConnectionStatus.PENDING.value
    )
    nickname: Mapped[Optional[str]] = mapped_column(String(100))
    last_interaction: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    # Relationships
    user: Mapped["User"] = relationship("User", foreign_keys=[user_id])  # noqa: F821
    connected_user: Mapped["User"] = relationship("User", foreign_keys=[connected_user_id])  # noqa: F821

    def __repr__(self) -> str:
        return f"<Connection {self.user_id} ↔ {self.connected_user_id} ({self.connection_type})>"
