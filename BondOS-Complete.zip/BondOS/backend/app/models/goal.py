"""BondOS – Goal Model (shared goals with streaks)"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, Float, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class Goal(Base):
    __tablename__ = "goals"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    creator_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    partner_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    emoji: Mapped[Optional[str]] = mapped_column(String(10))
    target_value: Mapped[Optional[float]] = mapped_column(Float)
    current_value: Mapped[float] = mapped_column(Float, default=0.0)
    unit: Mapped[Optional[str]] = mapped_column(String(30))
    streak_days: Mapped[int] = mapped_column(Integer, default=0)
    is_completed: Mapped[bool] = mapped_column(Boolean, default=False)
    due_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    creator: Mapped["User"] = relationship("User", foreign_keys=[creator_id], back_populates="goals")  # noqa: F821
    partner: Mapped[Optional["User"]] = relationship("User", foreign_keys=[partner_id])  # noqa: F821
    updates: Mapped[list["GoalUpdate"]] = relationship(back_populates="goal", cascade="all, delete-orphan")

    @property
    def progress_percent(self) -> float:
        if not self.target_value or self.target_value == 0:
            return 0.0
        return min(100.0, (self.current_value / self.target_value) * 100)


class GoalUpdate(Base):
    __tablename__ = "goal_updates"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    goal_id: Mapped[int] = mapped_column(ForeignKey("goals.id"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    note: Mapped[Optional[str]] = mapped_column(Text)
    value_added: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    goal: Mapped["Goal"] = relationship(back_populates="updates")
    user: Mapped["User"] = relationship("User")  # noqa: F821
