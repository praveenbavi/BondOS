"""BondOS – Message Model (1:1 and group chat)"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum

from app.database import Base


class MessageType(str, enum.Enum):
    TEXT = "text"
    VOICE = "voice"
    IMAGE = "image"
    VIDEO = "video"
    STICKER = "sticker"
    REMINDER_REF = "reminder_ref"  # Smart reply reminder


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    receiver_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))  # null = group
    group_id: Mapped[Optional[int]] = mapped_column(ForeignKey("groups.id"))
    content: Mapped[Optional[str]] = mapped_column(Text)
    media_url: Mapped[Optional[str]] = mapped_column(String(500))
    message_type: Mapped[str] = mapped_column(String(20), default=MessageType.TEXT.value)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    reply_to_id: Mapped[Optional[int]] = mapped_column(ForeignKey("messages.id"))
    # Delayed message unlock
    unlock_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    is_unlocked: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    # Relationships
    sender: Mapped["User"] = relationship("User", foreign_keys=[sender_id], back_populates="sent_messages")  # noqa: F821
    receiver: Mapped[Optional["User"]] = relationship("User", foreign_keys=[receiver_id])  # noqa: F821
    reply_to: Mapped[Optional["Message"]] = relationship("Message", remote_side="Message.id")

    def __repr__(self) -> str:
        return f"<Message id={self.id} type={self.message_type}>"


class Group(Base):
    __tablename__ = "groups"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(500))
    creator_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    members: Mapped[list["GroupMember"]] = relationship(back_populates="group", cascade="all, delete-orphan")


class GroupMember(Base):
    __tablename__ = "group_members"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("groups.id"), nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    role: Mapped[str] = mapped_column(String(20), default="member")  # admin/member
    joined_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    group: Mapped["Group"] = relationship(back_populates="members")
    user: Mapped["User"] = relationship("User")  # noqa: F821
