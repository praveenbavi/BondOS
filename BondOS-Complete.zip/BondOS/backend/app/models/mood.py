"""BondOS – Mood Model"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


MOOD_STATES = {
    "happy":        ("😊", "green"),
    "excited":      ("🤩", "yellow"),
    "calm":         ("😌", "blue"),
    "okay":         ("😐", "gray"),
    "tired":        ("😴", "purple"),
    "anxious":      ("😰", "orange"),
    "sad":          ("😢", "blue"),
    "needs_support":("🆘", "red"),
    "neutral":      ("😐", "gray"),
}


class Mood(Base):
    __tablename__ = "moods"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False, index=True)
    mood: Mapped[str] = mapped_column(String(50), nullable=False, default="neutral")
    emoji: Mapped[Optional[str]] = mapped_column(String(10))
    note: Mapped[Optional[str]] = mapped_column(Text)
    # Visibility control
    visible_to: Mapped[str] = mapped_column(String(30), default="close_circle")
    is_support_triggered: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    user: Mapped["User"] = relationship("User", back_populates="moods")  # noqa: F821

    @property
    def color(self) -> str:
        return MOOD_STATES.get(self.mood, ("😐", "gray"))[1]

    def __repr__(self) -> str:
        return f"<Mood user={self.user_id} mood={self.mood}>"
