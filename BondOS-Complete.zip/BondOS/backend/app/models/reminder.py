"""BondOS – Reminder Model (approval-based reminder system)"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum

from app.database import Base


class ReminderType(str, enum.Enum):
    SOFT = "soft"          # gentle notification
    ALARM = "alarm"        # louder alert
    PERSISTENT = "persistent"  # keeps repeating until dismissed


class ReminderStatus(str, enum.Enum):
    PENDING = "pending"       # waiting for approval
    APPROVED = "approved"     # receiver accepted
    REJECTED = "rejected"     # receiver declined
    ACTIVE = "active"         # approved + currently active
    COMPLETED = "completed"   # done / acknowledged
    SCHEDULED = "scheduled"   # future-dated, not yet sent


class RepeatType(str, enum.Enum):
    NONE = "none"
    DAILY = "daily"
    WEEKLY = "weekly"
    CUSTOM = "custom"


class Reminder(Base):
    __tablename__ = "reminders"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    receiver_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    reminder_type: Mapped[str] = mapped_column(String(20), default=ReminderType.SOFT.value)
    status: Mapped[str] = mapped_column(String(20), default=ReminderStatus.PENDING.value)
    remind_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    repeat_type: Mapped[str] = mapped_column(String(20), default=RepeatType.NONE.value)
    sound: Mapped[Optional[str]] = mapped_column(String(50), default="gentle_ping")
    priority: Mapped[str] = mapped_column(String(10), default="normal")  # low/normal/high
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    rejected_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    # Relationships
    sender: Mapped["User"] = relationship("User", foreign_keys=[sender_id], back_populates="sent_reminders")  # noqa: F821
    receiver: Mapped["User"] = relationship("User", foreign_keys=[receiver_id], back_populates="received_reminders")  # noqa: F821

    def __repr__(self) -> str:
        return f"<Reminder id={self.id} {self.sender_id}→{self.receiver_id} [{self.status}]>"
