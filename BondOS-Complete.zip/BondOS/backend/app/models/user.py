"""BondOS – User Model"""
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(500))
    bio: Mapped[Optional[str]] = mapped_column(Text)
    mood: Mapped[Optional[str]] = mapped_column(String(50), default="neutral")
    mood_emoji: Mapped[Optional[str]] = mapped_column(String(10), default="😐")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_quiet_mode: Mapped[bool] = mapped_column(Boolean, default=False)
    quiet_mode_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    location_sharing: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    moods: Mapped[list["Mood"]] = relationship(back_populates="user", cascade="all, delete-orphan")  # noqa: F821
    sent_reminders: Mapped[list["Reminder"]] = relationship(  # noqa: F821
        back_populates="sender", foreign_keys="Reminder.sender_id", cascade="all, delete-orphan"
    )
    received_reminders: Mapped[list["Reminder"]] = relationship(  # noqa: F821
        back_populates="receiver", foreign_keys="Reminder.receiver_id"
    )
    sent_messages: Mapped[list["Message"]] = relationship(  # noqa: F821
        back_populates="sender", foreign_keys="Message.sender_id"
    )
    posts: Mapped[list["Post"]] = relationship(back_populates="author", cascade="all, delete-orphan")  # noqa: F821
    location: Mapped[Optional["Location"]] = relationship(back_populates="user", uselist=False)  # noqa: F821
    goals: Mapped[list["Goal"]] = relationship(back_populates="creator", foreign_keys="Goal.creator_id")  # noqa: F821

    def __repr__(self) -> str:
        return f"<User id={self.id} username={self.username!r}>"
