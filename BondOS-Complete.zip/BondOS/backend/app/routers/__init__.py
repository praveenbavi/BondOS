"""BondOS – All Feature Routers"""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, get_current_user_id, pagination_params
from app.services import (
    UserService, ConnectionService, ReminderService,
    MessageService, MoodService, PulseService,
)
from app.schemas import (
    ConnectionCreate, ConnectionOut,
    ReminderCreate, ReminderApprove, ReminderOut,
    MessageCreate, MessageOut,
    MoodCreate, MoodOut,
    PostCreate, PostOut,
    LocationUpdate, LocationOut,
    AnonymousPostCreate, AnonymousPostOut,
    GoalCreate, GoalOut,
    MessageResponse, PulseOut,
)
from app.schemas.user import UserPublic, UserUpdate


# ── Users ─────────────────────────────────────────────────────────────────────
users_router = APIRouter(prefix="/users", tags=["Users"])


@users_router.get("/search", response_model=list[UserPublic])
async def search_users(
    q: str = Query(..., min_length=1),
    db: AsyncSession = Depends(get_db),
    _: int = Depends(get_current_user_id),
):
    return [UserPublic.model_validate(u) for u in await UserService.search_users(db, q)]


@users_router.get("/{user_id}", response_model=UserPublic)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    _: int = Depends(get_current_user_id),
):
    user = await UserService.get_by_id(db, user_id)
    if not user:
        raise HTTPException(404, "User not found")
    return UserPublic.model_validate(user)


@users_router.patch("/me", response_model=UserPublic)
async def update_me(
    data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    user = await UserService.update(db, uid, data)
    if not user:
        raise HTTPException(404, "User not found")
    return UserPublic.model_validate(user)


# ── Connections ───────────────────────────────────────────────────────────────
connections_router = APIRouter(prefix="/connections", tags=["Connections"])


@connections_router.post("", response_model=ConnectionOut, status_code=201)
async def add_connection(
    data: ConnectionCreate,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    try:
        conn = await ConnectionService.send_request(db, uid, data)
    except ValueError as e:
        raise HTTPException(409, str(e))
    return ConnectionOut.model_validate(conn)


@connections_router.post("/{connection_id}/accept", response_model=MessageResponse)
async def accept_connection(
    connection_id: int,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    conn = await ConnectionService.accept(db, connection_id, uid)
    if not conn:
        raise HTTPException(404, "Connection request not found")
    return MessageResponse(message="Connection accepted")


@connections_router.get("", response_model=list[dict])
async def list_connections(
    connection_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return await ConnectionService.get_connections(db, uid, connection_type)


# ── Reminders ─────────────────────────────────────────────────────────────────
reminders_router = APIRouter(prefix="/reminders", tags=["Reminders"])


@reminders_router.post("", response_model=ReminderOut, status_code=201)
async def send_reminder(
    data: ReminderCreate,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return ReminderOut.model_validate(await ReminderService.create(db, uid, data))


@reminders_router.post("/{reminder_id}/approve", response_model=ReminderOut)
async def approve_reminder(
    reminder_id: int,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    reminder = await ReminderService.approve(db, reminder_id, uid)
    if not reminder:
        raise HTTPException(404, "Reminder not found or already actioned")
    return ReminderOut.model_validate(reminder)


@reminders_router.post("/{reminder_id}/reject", response_model=ReminderOut)
async def reject_reminder(
    reminder_id: int,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    reminder = await ReminderService.reject(db, reminder_id, uid)
    if not reminder:
        raise HTTPException(404, "Reminder not found or already actioned")
    return ReminderOut.model_validate(reminder)


@reminders_router.post("/{reminder_id}/complete", response_model=ReminderOut)
async def complete_reminder(
    reminder_id: int,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    reminder = await ReminderService.complete(db, reminder_id, uid)
    if not reminder:
        raise HTTPException(404, "Reminder not found")
    return ReminderOut.model_validate(reminder)


@reminders_router.get("/sent", response_model=list[ReminderOut])
async def sent_reminders(
    p: dict = Depends(pagination_params),
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return [ReminderOut.model_validate(r) for r in await ReminderService.get_sent(db, uid, **p)]


@reminders_router.get("/received", response_model=list[ReminderOut])
async def received_reminders(
    p: dict = Depends(pagination_params),
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return [ReminderOut.model_validate(r) for r in await ReminderService.get_received(db, uid, **p)]


@reminders_router.get("/active", response_model=list[ReminderOut])
async def active_reminders(
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return [ReminderOut.model_validate(r) for r in await ReminderService.get_active(db, uid)]


# ── Messages ──────────────────────────────────────────────────────────────────
messages_router = APIRouter(prefix="/messages", tags=["Messages"])


@messages_router.post("", response_model=MessageOut, status_code=201)
async def send_message(
    data: MessageCreate,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    msg = await MessageService.send(
        db,
        sender_id=uid,
        receiver_id=data.receiver_id,
        content=data.content,
        message_type=data.message_type,
        media_url=data.media_url,
        reply_to_id=data.reply_to_id,
        unlock_at=data.unlock_at,
        group_id=data.group_id,
    )
    if data.receiver_id:
        await ConnectionService.update_last_interaction(db, uid, data.receiver_id)
    return MessageOut.model_validate(msg)


@messages_router.get("/conversation/{partner_id}", response_model=list[MessageOut])
async def get_conversation(
    partner_id: int,
    p: dict = Depends(pagination_params),
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    msgs = await MessageService.get_conversation(db, uid, partner_id, **p)
    await MessageService.mark_read(db, uid, partner_id)
    return [MessageOut.model_validate(m) for m in msgs]


@messages_router.get("/list", response_model=list[dict])
async def conversations_list(
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return await MessageService.get_conversations_list(db, uid)


# ── Moods ─────────────────────────────────────────────────────────────────────
moods_router = APIRouter(prefix="/moods", tags=["Moods"])


@moods_router.post("", response_model=MoodOut, status_code=201)
async def set_mood(
    data: MoodCreate,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return MoodOut.model_validate(await MoodService.set_mood(db, uid, data))


@moods_router.get("/history", response_model=list[MoodOut])
async def mood_history(
    p: dict = Depends(pagination_params),
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    return [MoodOut.model_validate(m) for m in await MoodService.get_history(db, uid, **p)]


# ── Pulse ─────────────────────────────────────────────────────────────────────
pulse_router = APIRouter(prefix="/pulse", tags=["Pulse"])


@pulse_router.get("", response_model=PulseOut)
async def get_pulse(
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    data = await PulseService.get_pulse(db, uid)
    return PulseOut(**data)


# ── Anonymous ─────────────────────────────────────────────────────────────────
anonymous_router = APIRouter(prefix="/anonymous", tags=["Anonymous"])


@anonymous_router.post("", status_code=201)
async def post_anonymously(
    data: AnonymousPostCreate,
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    from app.models.anonymous import AnonymousPost
    post = AnonymousPost(
        author_id=uid,
        content=data.content,
        visible_to_circle=data.visible_to_circle,
    )
    db.add(post)
    await db.flush()
    return AnonymousPostOut.model_validate(post)


@anonymous_router.get("", response_model=list[AnonymousPostOut])
async def list_anonymous_posts(
    p: dict = Depends(pagination_params),
    db: AsyncSession = Depends(get_db),
    _: int = Depends(get_current_user_id),
):
    from sqlalchemy import select
    from app.models.anonymous import AnonymousPost
    result = await db.execute(
        select(AnonymousPost)
        .order_by(AnonymousPost.created_at.desc())
        .offset(p["skip"]).limit(p["limit"])
    )
    return [AnonymousPostOut.model_validate(p) for p in result.scalars().all()]


@anonymous_router.post("/{post_id}/react")
async def react_to_anonymous(
    post_id: int,
    emoji: str = "❤️",
    db: AsyncSession = Depends(get_db),
    uid: int = Depends(get_current_user_id),
):
    from sqlalchemy import select
    from app.models.anonymous import AnonymousPost, AnonymousReaction
    result = await db.execute(select(AnonymousPost).where(AnonymousPost.id == post_id))
    post = result.scalar_one_or_none()
    if not post:
        raise HTTPException(404, "Post not found")
    reaction = AnonymousReaction(post_id=post_id, reactor_id=uid, emoji=emoji)
    post.reaction_count += 1
    db.add(reaction)
    await db.flush()
    return MessageResponse(message="Reacted")
