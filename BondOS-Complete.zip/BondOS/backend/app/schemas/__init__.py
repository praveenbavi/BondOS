"""BondOS – All Remaining Schemas"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict


# ── Connection ────────────────────────────────────────────────────────────────
class ConnectionCreate(BaseModel):
    connected_user_id: int
    connection_type: str = "friend"
    nickname: Optional[str] = None


class ConnectionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    connected_user_id: int
    connection_type: str
    status: str
    nickname: Optional[str]
    last_interaction: Optional[datetime]
    created_at: datetime


# ── Reminder ──────────────────────────────────────────────────────────────────
class ReminderCreate(BaseModel):
    receiver_id: int
    message: str
    reminder_type: str = "soft"
    remind_at: Optional[datetime] = None
    repeat_type: str = "none"
    sound: str = "gentle_ping"
    priority: str = "normal"


class ReminderApprove(BaseModel):
    reminder_id: int


class ReminderOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    sender_id: int
    receiver_id: int
    message: str
    reminder_type: str
    status: str
    remind_at: Optional[datetime]
    repeat_type: str
    sound: Optional[str]
    priority: str
    approved_at: Optional[datetime]
    rejected_at: Optional[datetime]
    created_at: datetime


# ── Message ───────────────────────────────────────────────────────────────────
class MessageCreate(BaseModel):
    receiver_id: Optional[int] = None
    group_id: Optional[int] = None
    content: Optional[str] = None
    media_url: Optional[str] = None
    message_type: str = "text"
    reply_to_id: Optional[int] = None
    unlock_at: Optional[datetime] = None  # Delayed message


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    sender_id: int
    receiver_id: Optional[int]
    group_id: Optional[int]
    content: Optional[str]
    media_url: Optional[str]
    message_type: str
    is_read: bool
    reply_to_id: Optional[int]
    unlock_at: Optional[datetime]
    is_unlocked: bool
    created_at: datetime


# ── Post ──────────────────────────────────────────────────────────────────────
class PostCreate(BaseModel):
    caption: Optional[str] = None
    media_url: Optional[str] = None
    media_type: str = "photo"
    visibility: str = "all"
    is_story: bool = False


class PostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    caption: Optional[str]
    media_url: Optional[str]
    media_type: str
    visibility: str
    is_story: bool
    likes_count: int
    comments_count: int
    created_at: datetime


# ── Mood ──────────────────────────────────────────────────────────────────────
class MoodCreate(BaseModel):
    mood: str
    emoji: Optional[str] = None
    note: Optional[str] = None
    visible_to: str = "close_circle"


class MoodOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    mood: str
    emoji: Optional[str]
    note: Optional[str]
    visible_to: str
    is_support_triggered: bool
    created_at: datetime


# ── Location ──────────────────────────────────────────────────────────────────
class LocationUpdate(BaseModel):
    latitude: float
    longitude: float
    place_name: Optional[str] = None
    is_live: bool = False
    sharing_with: str = "close_circle"


class LocationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    user_id: int
    latitude: float
    longitude: float
    place_name: Optional[str]
    is_live: bool
    sharing_with: str
    updated_at: datetime


# ── Anonymous Post ────────────────────────────────────────────────────────────
class AnonymousPostCreate(BaseModel):
    content: str
    visible_to_circle: str = "all"


class AnonymousPostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    content: str
    visible_to_circle: str
    reaction_count: int
    comment_count: int
    created_at: datetime
    # author_id intentionally excluded for anonymity


# ── Goal ──────────────────────────────────────────────────────────────────────
class GoalCreate(BaseModel):
    partner_id: Optional[int] = None
    title: str
    description: Optional[str] = None
    emoji: Optional[str] = None
    target_value: Optional[float] = None
    unit: Optional[str] = None
    due_date: Optional[datetime] = None


class GoalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    creator_id: int
    partner_id: Optional[int]
    title: str
    description: Optional[str]
    emoji: Optional[str]
    target_value: Optional[float]
    current_value: float
    unit: Optional[str]
    streak_days: int
    is_completed: bool
    progress_percent: float
    created_at: datetime


# ── Generic ───────────────────────────────────────────────────────────────────
class MessageResponse(BaseModel):
    message: str
    success: bool = True


class PulseOut(BaseModel):
    """Aggregated mood health of your connections."""
    good: int
    okay: int
    needs_support: int
    total: int
    people: list[dict]
