"""BondOS – User Schemas (Pydantic v2)"""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, field_validator, ConfigDict


class UserBase(BaseModel):
    name: str
    username: str
    email: EmailStr
    avatar_url: Optional[str] = None
    bio: Optional[str] = None


class UserCreate(UserBase):
    password: str

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class UserUpdate(BaseModel):
    name: Optional[str] = None
    bio: Optional[str] = None
    avatar_url: Optional[str] = None
    mood: Optional[str] = None
    mood_emoji: Optional[str] = None
    is_quiet_mode: Optional[bool] = None
    location_sharing: Optional[bool] = None


class UserPublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    username: str
    avatar_url: Optional[str]
    mood: Optional[str]
    mood_emoji: Optional[str]
    is_quiet_mode: bool
    created_at: datetime


class UserDetail(UserPublic):
    email: str
    bio: Optional[str]
    location_sharing: bool
    updated_at: datetime


class UserMoodUpdate(BaseModel):
    mood: str
    emoji: Optional[str] = None
    note: Optional[str] = None
    visible_to: str = "close_circle"


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserPublic


class LoginRequest(BaseModel):
    email: EmailStr
    password: str
