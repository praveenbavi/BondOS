"""BondOS – Auth Service"""
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.core.security import hash_password, verify_password, create_access_token
from app.schemas.user import UserCreate


class AuthService:

    @staticmethod
    async def register(db: AsyncSession, data: UserCreate) -> User:
        """Create a new user account."""
        # Check uniqueness
        existing = await db.execute(
            select(User).where(
                (User.email == data.email) | (User.username == data.username)
            )
        )
        if existing.scalar_one_or_none():
            raise ValueError("Email or username already taken")

        user = User(
            name=data.name,
            username=data.username,
            email=data.email,
            hashed_password=hash_password(data.password),
            avatar_url=data.avatar_url,
            bio=data.bio,
        )
        db.add(user)
        await db.flush()
        await db.refresh(user)
        return user

    @staticmethod
    async def authenticate(
        db: AsyncSession, email: str, password: str
    ) -> Optional[User]:
        """Return user if credentials are valid, else None."""
        result = await db.execute(select(User).where(User.email == email))
        user = result.scalar_one_or_none()
        if not user or not verify_password(password, user.hashed_password):
            return None
        if not user.is_active:
            return None
        return user

    @staticmethod
    def issue_token(user: User) -> str:
        return create_access_token(subject=user.id)
