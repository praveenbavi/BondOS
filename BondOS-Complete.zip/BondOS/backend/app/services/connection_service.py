"""BondOS – Connection Service"""
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, or_, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.connection import Connection, ConnectionStatus
from app.models.user import User
from app.schemas import ConnectionCreate


class ConnectionService:

    @staticmethod
    async def send_request(
        db: AsyncSession, user_id: int, data: ConnectionCreate
    ) -> Connection:
        # Check if already exists
        existing = await db.execute(
            select(Connection).where(
                or_(
                    and_(Connection.user_id == user_id, Connection.connected_user_id == data.connected_user_id),
                    and_(Connection.user_id == data.connected_user_id, Connection.connected_user_id == user_id),
                )
            )
        )
        if existing.scalar_one_or_none():
            raise ValueError("Connection already exists")

        conn = Connection(
            user_id=user_id,
            connected_user_id=data.connected_user_id,
            connection_type=data.connection_type,
            nickname=data.nickname,
            status=ConnectionStatus.PENDING.value,
        )
        db.add(conn)
        await db.flush()
        await db.refresh(conn)
        return conn

    @staticmethod
    async def accept(db: AsyncSession, connection_id: int, user_id: int) -> Optional[Connection]:
        result = await db.execute(
            select(Connection).where(
                Connection.id == connection_id,
                Connection.connected_user_id == user_id,
                Connection.status == ConnectionStatus.PENDING.value,
            )
        )
        conn = result.scalar_one_or_none()
        if not conn:
            return None
        conn.status = ConnectionStatus.ACCEPTED.value
        # Create reverse connection
        reverse = Connection(
            user_id=user_id,
            connected_user_id=conn.user_id,
            connection_type=conn.connection_type,
            status=ConnectionStatus.ACCEPTED.value,
        )
        db.add(reverse)
        await db.flush()
        return conn

    @staticmethod
    async def get_connections(
        db: AsyncSession, user_id: int, connection_type: Optional[str] = None
    ) -> list[dict]:
        query = select(Connection, User).join(
            User, User.id == Connection.connected_user_id
        ).where(
            Connection.user_id == user_id,
            Connection.status == ConnectionStatus.ACCEPTED.value,
        )
        if connection_type:
            query = query.where(Connection.connection_type == connection_type)

        result = await db.execute(query.order_by(Connection.last_interaction.desc()))
        rows = result.all()

        return [
            {
                "connection": conn,
                "user": {
                    "id": user.id,
                    "name": user.name,
                    "username": user.username,
                    "avatar_url": user.avatar_url,
                    "mood": user.mood,
                    "mood_emoji": user.mood_emoji,
                    "is_quiet_mode": user.is_quiet_mode,
                    "last_interaction": conn.last_interaction,
                    "connection_type": conn.connection_type,
                    "nickname": conn.nickname,
                },
            }
            for conn, user in rows
        ]

    @staticmethod
    async def update_last_interaction(
        db: AsyncSession, user_id: int, partner_id: int
    ) -> None:
        result = await db.execute(
            select(Connection).where(
                Connection.user_id == user_id,
                Connection.connected_user_id == partner_id,
            )
        )
        conn = result.scalar_one_or_none()
        if conn:
            conn.last_interaction = datetime.now(timezone.utc)
            await db.flush()
