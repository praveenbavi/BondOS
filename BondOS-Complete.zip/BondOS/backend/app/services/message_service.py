"""BondOS – Message Service"""
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.message import Message, MessageType


class MessageService:

    @staticmethod
    async def send(
        db: AsyncSession,
        sender_id: int,
        receiver_id: Optional[int],
        content: Optional[str],
        message_type: str = "text",
        media_url: Optional[str] = None,
        reply_to_id: Optional[int] = None,
        unlock_at: Optional[datetime] = None,
        group_id: Optional[int] = None,
    ) -> Message:
        msg = Message(
            sender_id=sender_id,
            receiver_id=receiver_id,
            group_id=group_id,
            content=content,
            media_url=media_url,
            message_type=message_type,
            reply_to_id=reply_to_id,
            unlock_at=unlock_at,
            is_unlocked=(unlock_at is None),
        )
        db.add(msg)
        await db.flush()
        await db.refresh(msg)
        return msg

    @staticmethod
    async def get_conversation(
        db: AsyncSession,
        user_a: int,
        user_b: int,
        skip: int = 0,
        limit: int = 50,
    ) -> list[Message]:
        """Fetch 1:1 conversation between two users."""
        result = await db.execute(
            select(Message)
            .where(
                or_(
                    and_(Message.sender_id == user_a, Message.receiver_id == user_b),
                    and_(Message.sender_id == user_b, Message.receiver_id == user_a),
                ),
                Message.is_deleted == False,  # noqa: E712
            )
            .order_by(Message.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return list(reversed(result.scalars().all()))

    @staticmethod
    async def mark_read(
        db: AsyncSession, receiver_id: int, sender_id: int
    ) -> int:
        """Mark all messages from sender as read. Returns count updated."""
        result = await db.execute(
            select(Message).where(
                Message.receiver_id == receiver_id,
                Message.sender_id == sender_id,
                Message.is_read == False,  # noqa: E712
            )
        )
        messages = result.scalars().all()
        for m in messages:
            m.is_read = True
        await db.flush()
        return len(messages)

    @staticmethod
    async def get_conversations_list(
        db: AsyncSession, user_id: int
    ) -> list[dict]:
        """Return latest message per conversation partner."""
        result = await db.execute(
            select(Message)
            .where(
                or_(Message.sender_id == user_id, Message.receiver_id == user_id),
                Message.is_deleted == False,  # noqa: E712
            )
            .order_by(Message.created_at.desc())
        )
        messages = result.scalars().all()

        seen: dict[int, Message] = {}
        for msg in messages:
            partner = msg.receiver_id if msg.sender_id == user_id else msg.sender_id
            if partner and partner not in seen:
                seen[partner] = msg

        return [
            {
                "partner_id": pid,
                "last_message": msg.content or f"[{msg.message_type}]",
                "created_at": msg.created_at,
                "is_read": msg.is_read,
            }
            for pid, msg in seen.items()
        ]

    @staticmethod
    async def unlock_delayed(db: AsyncSession) -> int:
        """Unlock all messages whose unlock_at has passed. Call periodically."""
        now = datetime.now(timezone.utc)
        result = await db.execute(
            select(Message).where(
                Message.is_unlocked == False,  # noqa: E712
                Message.unlock_at <= now,
            )
        )
        messages = result.scalars().all()
        for m in messages:
            m.is_unlocked = True
        await db.flush()
        return len(messages)
