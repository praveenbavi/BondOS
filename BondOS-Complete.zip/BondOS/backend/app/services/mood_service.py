"""BondOS – Mood Service"""
from typing import Optional

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.mood import Mood, MOOD_STATES
from app.models.connection import Connection, ConnectionStatus
from app.models.user import User
from app.schemas import MoodCreate


SUPPORT_MOODS = {"sad", "anxious", "needs_support"}
GOOD_MOODS = {"happy", "excited", "calm"}
OKAY_MOODS = {"okay", "tired", "neutral"}


class MoodService:

    @staticmethod
    async def set_mood(
        db: AsyncSession, user_id: int, data: MoodCreate
    ) -> Mood:
        emoji = data.emoji or MOOD_STATES.get(data.mood, ("😐", "gray"))[0]
        is_support = data.mood in SUPPORT_MOODS

        mood = Mood(
            user_id=user_id,
            mood=data.mood,
            emoji=emoji,
            note=data.note,
            visible_to=data.visible_to,
            is_support_triggered=is_support,
        )
        db.add(mood)

        # Update user's current mood
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if user:
            user.mood = data.mood
            user.mood_emoji = emoji

        await db.flush()
        await db.refresh(mood)
        return mood

    @staticmethod
    async def get_latest(db: AsyncSession, user_id: int) -> Optional[Mood]:
        result = await db.execute(
            select(Mood)
            .where(Mood.user_id == user_id)
            .order_by(Mood.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_history(
        db: AsyncSession, user_id: int, skip: int = 0, limit: int = 30
    ) -> list[Mood]:
        result = await db.execute(
            select(Mood)
            .where(Mood.user_id == user_id)
            .order_by(Mood.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())


class PulseService:
    """Aggregate mood health of a user's connections."""

    @staticmethod
    async def get_pulse(db: AsyncSession, user_id: int) -> dict:
        # Get all accepted connections
        result = await db.execute(
            select(Connection).where(
                Connection.user_id == user_id,
                Connection.status == ConnectionStatus.ACCEPTED.value,
            )
        )
        connections = result.scalars().all()
        partner_ids = [c.connected_user_id for c in connections]

        if not partner_ids:
            return {"good": 0, "okay": 0, "needs_support": 0, "total": 0, "people": []}

        # Get latest mood for each partner
        people = []
        good = okay = needs_support = 0

        for pid in partner_ids:
            user_result = await db.execute(select(User).where(User.id == pid))
            partner = user_result.scalar_one_or_none()
            if not partner:
                continue

            mood_result = await db.execute(
                select(Mood)
                .where(Mood.user_id == pid)
                .order_by(Mood.created_at.desc())
                .limit(1)
            )
            latest_mood = mood_result.scalar_one_or_none()
            mood_label = latest_mood.mood if latest_mood else partner.mood or "neutral"

            if mood_label in GOOD_MOODS:
                good += 1
                category = "good"
            elif mood_label in SUPPORT_MOODS:
                needs_support += 1
                category = "needs_support"
            else:
                okay += 1
                category = "okay"

            people.append({
                "user_id": pid,
                "name": partner.name,
                "username": partner.username,
                "avatar_url": partner.avatar_url,
                "mood": mood_label,
                "mood_emoji": partner.mood_emoji or "😐",
                "category": category,
            })

        return {
            "good": good,
            "okay": okay,
            "needs_support": needs_support,
            "total": len(people),
            "people": people,
        }
