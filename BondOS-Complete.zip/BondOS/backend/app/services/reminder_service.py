"""BondOS – Reminder Service (approval-based)"""
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.reminder import Reminder, ReminderStatus
from app.schemas import ReminderCreate


class ReminderService:

    @staticmethod
    async def create(db: AsyncSession, sender_id: int, data: ReminderCreate) -> Reminder:
        reminder = Reminder(
            sender_id=sender_id,
            receiver_id=data.receiver_id,
            message=data.message,
            reminder_type=data.reminder_type,
            status=ReminderStatus.PENDING.value,
            remind_at=data.remind_at,
            repeat_type=data.repeat_type,
            sound=data.sound,
            priority=data.priority,
        )
        db.add(reminder)
        await db.flush()
        await db.refresh(reminder)
        return reminder

    @staticmethod
    async def approve(
        db: AsyncSession, reminder_id: int, receiver_id: int
    ) -> Optional[Reminder]:
        result = await db.execute(
            select(Reminder).where(
                Reminder.id == reminder_id,
                Reminder.receiver_id == receiver_id,
                Reminder.status == ReminderStatus.PENDING.value,
            )
        )
        reminder = result.scalar_one_or_none()
        if not reminder:
            return None
        reminder.status = ReminderStatus.APPROVED.value
        reminder.approved_at = datetime.now(timezone.utc)
        await db.flush()
        return reminder

    @staticmethod
    async def reject(
        db: AsyncSession, reminder_id: int, receiver_id: int
    ) -> Optional[Reminder]:
        result = await db.execute(
            select(Reminder).where(
                Reminder.id == reminder_id,
                Reminder.receiver_id == receiver_id,
                Reminder.status == ReminderStatus.PENDING.value,
            )
        )
        reminder = result.scalar_one_or_none()
        if not reminder:
            return None
        reminder.status = ReminderStatus.REJECTED.value
        reminder.rejected_at = datetime.now(timezone.utc)
        await db.flush()
        return reminder

    @staticmethod
    async def complete(
        db: AsyncSession, reminder_id: int, user_id: int
    ) -> Optional[Reminder]:
        result = await db.execute(
            select(Reminder).where(
                Reminder.id == reminder_id,
                Reminder.receiver_id == user_id,
            )
        )
        reminder = result.scalar_one_or_none()
        if not reminder:
            return None
        reminder.status = ReminderStatus.COMPLETED.value
        reminder.completed_at = datetime.now(timezone.utc)
        await db.flush()
        return reminder

    @staticmethod
    async def get_sent(
        db: AsyncSession, sender_id: int, skip: int = 0, limit: int = 20
    ) -> list[Reminder]:
        result = await db.execute(
            select(Reminder)
            .where(Reminder.sender_id == sender_id)
            .order_by(Reminder.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_received(
        db: AsyncSession, receiver_id: int, skip: int = 0, limit: int = 20
    ) -> list[Reminder]:
        result = await db.execute(
            select(Reminder)
            .where(Reminder.receiver_id == receiver_id)
            .order_by(Reminder.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        return list(result.scalars().all())

    @staticmethod
    async def get_active(db: AsyncSession, user_id: int) -> list[Reminder]:
        """All active approved reminders for a receiver."""
        result = await db.execute(
            select(Reminder).where(
                Reminder.receiver_id == user_id,
                Reminder.status == ReminderStatus.APPROVED.value,
            ).order_by(Reminder.remind_at.asc())
        )
        return list(result.scalars().all())
