"""BondOS – User Service"""
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.schemas.user import UserUpdate


class UserService:

    @staticmethod
    async def get_by_id(db: AsyncSession, user_id: int) -> Optional[User]:
        result = await db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    @staticmethod
    async def get_by_username(db: AsyncSession, username: str) -> Optional[User]:
        result = await db.execute(select(User).where(User.username == username))
        return result.scalar_one_or_none()

    @staticmethod
    async def search_users(db: AsyncSession, query: str, limit: int = 10) -> list[User]:
        result = await db.execute(
            select(User)
            .where(
                (User.username.ilike(f"%{query}%")) | (User.name.ilike(f"%{query}%"))
            )
            .limit(limit)
        )
        return list(result.scalars().all())

    @staticmethod
    async def update(db: AsyncSession, user_id: int, data: UserUpdate) -> Optional[User]:
        user = await UserService.get_by_id(db, user_id)
        if not user:
            return None
        for field, value in data.model_dump(exclude_unset=True).items():
            setattr(user, field, value)
        await db.flush()
        await db.refresh(user)
        return user

    @staticmethod
    async def set_quiet_mode(
        db: AsyncSession, user_id: int, enabled: bool, until=None
    ) -> Optional[User]:
        user = await UserService.get_by_id(db, user_id)
        if not user:
            return None
        user.is_quiet_mode = enabled
        user.quiet_mode_until = until
        await db.flush()
        await db.refresh(user)
        return user
