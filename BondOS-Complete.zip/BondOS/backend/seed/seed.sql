-- ============================================================
-- BondOS – Seed Data (SQLite-compatible)
-- Run automatically on startup via load_seed_data()
-- ============================================================

-- ── Users (passwords are bcrypt of "password123") ──────────
INSERT OR IGNORE INTO users
  (id, name, username, email, hashed_password, avatar_url, bio, mood, mood_emoji, is_active, location_sharing)
VALUES
  (1,  'Aviral Sharma',  'aviral_07',  'aviral@bonidos.app',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGc8L4oJQmS4/JFJiZ1xQwjUDki',
   'https://i.pravatar.cc/150?img=1',  'Building BondOS 💙', 'happy', '😊', 1, 1),

  (2,  'Ananya Patel',   'ananya_p',   'ananya@bonidos.app',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGc8L4oJQmS4/JFJiZ1xQwjUDki',
   'https://i.pravatar.cc/150?img=2',  'Designer & dreamer ✨', 'excited', '🤩', 1, 1),

  (3,  'Rohan Mehta',    'rohan_m',    'rohan@bonidos.app',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGc8L4oJQmS4/JFJiZ1xQwjUDki',
   'https://i.pravatar.cc/150?img=3',  'Coffee + code ☕', 'okay', '😐', 1, 0),

  (4,  'Priya Singh',    'priya_s',    'priya@bonidos.app',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGc8L4oJQmS4/JFJiZ1xQwjUDki',
   'https://i.pravatar.cc/150?img=5',  'Mom of two 👶👶', 'happy', '😊', 1, 1),

  (5,  'Dev Kapoor',     'dev_k',      'dev@bonidos.app',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGc8L4oJQmS4/JFJiZ1xQwjUDki',
   'https://i.pravatar.cc/150?img=7',  'Just vibing 🌊', 'tired', '😴', 1, 0),

  (6,  'Meera Nair',     'meera_n',    'meera@bonidos.app',
   '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TiGc8L4oJQmS4/JFJiZ1xQwjUDki',
   'https://i.pravatar.cc/150?img=9',  'Lost in books 📚', 'needs_support', '🆘', 1, 1);

-- ── Connections ────────────────────────────────────────────
INSERT OR IGNORE INTO connections (id, user_id, connected_user_id, connection_type, status, last_interaction)
VALUES
  (1,  1, 2, 'bestie',       'accepted', datetime('now', '-2 hours')),
  (2,  2, 1, 'bestie',       'accepted', datetime('now', '-2 hours')),
  (3,  1, 3, 'close_circle', 'accepted', datetime('now', '-1 day')),
  (4,  3, 1, 'close_circle', 'accepted', datetime('now', '-1 day')),
  (5,  1, 4, 'family',       'accepted', datetime('now', '-3 hours')),
  (6,  4, 1, 'family',       'accepted', datetime('now', '-3 hours')),
  (7,  1, 5, 'friend',       'accepted', datetime('now', '-5 days')),
  (8,  5, 1, 'friend',       'accepted', datetime('now', '-5 days')),
  (9,  1, 6, 'close_circle', 'accepted', datetime('now', '-4 hours')),
  (10, 6, 1, 'close_circle', 'accepted', datetime('now', '-4 hours'));

-- ── Moods ──────────────────────────────────────────────────
INSERT OR IGNORE INTO moods (id, user_id, mood, emoji, note, visible_to, is_support_triggered)
VALUES
  (1, 1, 'happy',         '😊', 'Great day shipping features!', 'close_circle', 0),
  (2, 2, 'excited',       '🤩', 'Got a new project!',           'all',          0),
  (3, 3, 'okay',          '😐', NULL,                            'close_circle', 0),
  (4, 4, 'happy',         '😊', 'Kids were good today ❤️',      'family',       0),
  (5, 5, 'tired',         '😴', 'Long week…',                   'close_circle', 0),
  (6, 6, 'needs_support', '🆘', 'Having a tough time',          'close_circle', 1);

-- ── Reminders ──────────────────────────────────────────────
INSERT OR IGNORE INTO reminders
  (id, sender_id, receiver_id, message, reminder_type, status, remind_at, repeat_type, sound, priority)
VALUES
  (1, 1, 2, 'Don''t forget to drink water 💧',
   'soft', 'approved', datetime('now', '+1 hour'), 'daily', 'gentle_ping', 'normal'),
  (2, 2, 1, 'Call Ananya ❤️',
   'alarm', 'active',  datetime('now', '+30 minutes'), 'none', 'gentle_ping', 'high'),
  (3, 1, 3, 'Send good morning text ☀️',
   'soft', 'scheduled', datetime('now', '+18 hours'), 'daily', 'gentle_ping', 'low'),
  (4, 4, 1, 'Study time! 📚',
   'alarm', 'active',  datetime('now', '+2 hours'), 'daily', 'gentle_ping', 'normal'),
  (5, 1, 6, 'Check in on Meera 💙',
   'soft', 'pending',  NULL, 'none', 'gentle_ping', 'high');

-- ── Messages ───────────────────────────────────────────────
INSERT OR IGNORE INTO messages (id, sender_id, receiver_id, content, message_type, is_read)
VALUES
  (1, 1, 2, 'Hey! Don''t forget our movie night! 🎬', 'text', 1),
  (2, 2, 1, 'Can''t wait! ❤️',                         'text', 1),
  (3, 3, 1, 'Dude what''s the plan for weekend?',      'text', 0),
  (4, 1, 3, 'Let''s go hiking! 🏔️',                   'text', 1),
  (5, 6, 1, 'I''m not feeling great today…',           'text', 0),
  (6, 4, 1, 'Happy Tuesday! ☀️',                       'text', 1);

-- ── Posts ──────────────────────────────────────────────────
INSERT OR IGNORE INTO posts (id, user_id, caption, media_url, media_type, visibility, likes_count, comments_count)
VALUES
  (1, 3, 'Beautiful sunset today! 🌅',
   'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400',
   'photo', 'all', 23, 8),
  (2, 2, 'New design shipped ✨',
   'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
   'photo', 'close_circle', 45, 12),
  (3, 1, 'Sunday brunch 🥐',
   'https://images.unsplash.com/photo-1495147466023-ac5c588e2e94?w=400',
   'photo', 'all', 67, 15);

-- ── Anonymous Posts ────────────────────────────────────────
INSERT OR IGNORE INTO anonymous_posts (id, content, visible_to_circle, reaction_count, comment_count)
VALUES
  (1, 'Sometimes I just feel unimportant to everyone.', 'all', 45, 12),
  (2, 'What''s one thing you wish you could start over?', 'all', 32, 25),
  (3, 'I miss the old days when things were simpler.', 'close_circle', 18, 7),
  (4, 'Does anyone else feel like they''re running out of time?', 'all', 61, 30);

-- ── Locations ──────────────────────────────────────────────
INSERT OR IGNORE INTO locations (id, user_id, latitude, longitude, place_name, is_live, sharing_with)
VALUES
  (1, 2, 19.0760, 72.8777, 'Park Street',  1, 'close_circle'),
  (3, 3, 19.0330, 73.0297, 'College',      1, 'close_circle'),
  (4, 4, 18.5204, 73.8567, 'Home',         1, 'family');

-- ── Goals ──────────────────────────────────────────────────
INSERT OR IGNORE INTO goals
  (id, creator_id, partner_id, title, emoji, target_value, current_value, unit, streak_days)
VALUES
  (1, 1, 2, 'Run 5km together',     '🏃', 5.0,  2.5,  'km',     3),
  (2, 1, 3, 'Read 10 books',        '📚', 10.0, 4.0,  'books',  0),
  (3, 2, 1, 'Meditate daily',       '🧘', 30.0, 12.0, 'days',   12),
  (4, 4, 1, 'Family dinner weekly', '🍽️', 4.0,  2.0,  'dinners', 2);

-- ── Groups ─────────────────────────────────────────────────
INSERT OR IGNORE INTO groups (id, name, creator_id)
VALUES
  (1, 'Besties 🌟', 1),
  (2, 'Family Chat 🏠', 1);

INSERT OR IGNORE INTO group_members (id, group_id, user_id, role)
VALUES
  (1, 1, 1, 'admin'),
  (2, 1, 2, 'member'),
  (3, 1, 3, 'member'),
  (4, 2, 1, 'admin'),
  (5, 2, 4, 'member');
