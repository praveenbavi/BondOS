// src/App.jsx
import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '@/hooks'
import { Toaster } from 'react-hot-toast'

// Pages
import { Login, Register } from '@/pages/Auth'
import { Settings } from '@/pages/Settings'

// Components
import { Dashboard } from '@/components/dashboard'
import { ChatList, ChatDetail } from '@/components/chat'
import { Pulse } from '@/components/pulse'
import { Moments, Anonymous } from '@/components/moments'
import { Reminders } from '@/components/reminders'
import { BottomNav } from '@/components/common'

const PrivateRoute = ({ children }) => {
  const { isLoggedIn } = useAuth()
  return isLoggedIn ? children : <Navigate to="/login" />
}

export default function App() {
  const { isLoggedIn } = useAuth()

  return (
    <BrowserRouter>
      <Toaster position="top-center" />
      <Routes>
        {/* Public routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Protected routes */}
        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        <Route path="/chat" element={<PrivateRoute><ChatList /></PrivateRoute>} />
        <Route path="/chat/:partnerId" element={<PrivateRoute><ChatDetail /></PrivateRoute>} />
        <Route path="/pulse" element={<PrivateRoute><Pulse /></PrivateRoute>} />
        <Route path="/moments" element={<PrivateRoute><Moments /></PrivateRoute>} />
        <Route path="/anonymous" element={<PrivateRoute><Anonymous /></PrivateRoute>} />
        <Route path="/reminders" element={<PrivateRoute><Reminders /></PrivateRoute>} />
        <Route path="/settings" element={<PrivateRoute><Settings /></PrivateRoute>} />

        {/* Default redirect */}
        <Route path="/" element={<Navigate to={isLoggedIn ? '/dashboard' : '/login'} />} />
        <Route path="*" element={<Navigate to={isLoggedIn ? '/dashboard' : '/login'} />} />
      </Routes>

      {/* Bottom nav for protected routes */}
      {isLoggedIn && <BottomNav />}
    </BrowserRouter>
  )
}
