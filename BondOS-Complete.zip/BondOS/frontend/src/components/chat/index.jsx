// src/components/chat/ChatList.jsx
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMessages } from '@/hooks'
import { Layout, Card } from '@/components/common'
import { motion } from 'framer-motion'
import { MessageCircle } from 'lucide-react'
import { formatDistanceToNow } from 'date-fns'

export const ChatList = () => {
  const navigate = useNavigate()
  const { conversations, loadConversations } = useMessages()

  useEffect(() => {
    loadConversations()
  }, [])

  return (
    <Layout title="Messages" subtitle="Your conversations">
      <div className="p-4 space-y-3">
        {conversations.length === 0 ? (
          <div className="text-center py-12">
            <MessageCircle className="w-12 h-12 mx-auto opacity-20 mb-3" />
            <p className="text-bond-text-muted">No conversations yet</p>
          </div>
        ) : (
          conversations.map((conv, i) => (
            <motion.div
              key={conv.partner_id}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card
                onClick={() => navigate(`/chat/${conv.partner_id}`)}
                className="cursor-pointer hover:bg-bond-50 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-bond-200" />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-bond-900 truncate">Person</p>
                    <p className={`text-sm truncate ${conv.is_read ? 'text-bond-text-muted' : 'font-semibold text-bond-900'}`}>
                      {conv.last_message}
                    </p>
                  </div>
                  <p className="text-xs text-bond-text-muted">
                    {formatDistanceToNow(new Date(conv.created_at), { addSuffix: true })}
                  </p>
                </div>
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </Layout>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/chat/ChatDetail.jsx
import { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useMessages } from '@/hooks'
import { Layout, Button } from '@/components/common'
import { motion, AnimatePresence } from 'framer-motion'
import { Send } from 'lucide-react'

export const ChatDetail = () => {
  const { partnerId } = useParams()
  const navigate = useNavigate()
  const { messages, loadConversation, sendMessage } = useMessages()
  const [content, setContent] = useState('')
  const [isSending, setIsSending] = useState(false)
  const messagesRef = useRef(null)

  useEffect(() => {
    loadConversation(parseInt(partnerId))
  }, [partnerId])

  useEffect(() => {
    if (messagesRef.current) {
      messagesRef.current.scrollTop = messagesRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async () => {
    if (!content.trim()) return
    setIsSending(true)
    const success = await sendMessage(parseInt(partnerId), content)
    if (success) setContent('')
    setIsSending(false)
  }

  const conversation = messages[parseInt(partnerId)] || []

  return (
    <Layout title="Chat" back backFn={() => navigate('/chat')}>
      <div className="flex flex-col h-dvh pb-24">
        {/* Messages */}
        <div
          ref={messagesRef}
          className="flex-1 overflow-y-auto p-4 space-y-2"
        >
          <AnimatePresence>
            {conversation.map((msg, i) => (
              <motion.div
                key={msg.id}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                transition={{ delay: i * 0.02 }}
                className={`flex ${msg.sender_id === 1 ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-2xl ${
                    msg.sender_id === 1
                      ? 'bg-bond-600 text-white rounded-br-none'
                      : 'bg-bond-100 text-bond-900 rounded-bl-none'
                  }`}
                >
                  <p className="text-sm">{msg.content}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Input */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-bond-border p-4 max-w-md mx-auto">
          <div className="flex gap-2">
            <input
              type="text"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Type a message…"
              className="bond-input flex-1"
            />
            <button
              onClick={handleSend}
              disabled={isSending || !content.trim()}
              className="p-3 bg-bond-600 text-white rounded-xl hover:bg-bond-700 disabled:opacity-50 transition"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </Layout>
  )
}
