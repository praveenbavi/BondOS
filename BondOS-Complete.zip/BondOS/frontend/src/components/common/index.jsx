// src/components/common/Layout.jsx
import { motion } from 'framer-motion'

export const Layout = ({ children, title, subtitle, back, backFn }) => {
  return (
    <div className="page-container">
      {(title || back) && (
        <motion.header
          className="px-4 pt-4 pb-6 bg-white border-b border-bond-border sticky top-0 z-50"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center justify-between mb-2">
            {back ? (
              <button
                onClick={backFn}
                className="p-2 -ml-2 hover:bg-bond-50 rounded-lg transition"
              >
                ← Back
              </button>
            ) : (
              <div />
            )}
            {title && <h1 className="text-2xl font-bold text-bond-900">{title}</h1>}
            <div />
          </div>
          {subtitle && <p className="text-sm text-bond-text-muted">{subtitle}</p>}
        </motion.header>
      )}
      <div className="flex-1 overflow-y-auto content-with-nav">
        {children}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/common/BottomNav.jsx
import { Home, Heart, MessageCircle, Sparkles, Settings } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'

const navItems = [
  { path: '/dashboard', icon: Home, label: 'Home' },
  { path: '/pulse', icon: Heart, label: 'Pulse' },
  { path: '/chat', icon: MessageCircle, label: 'Chat' },
  { path: '/moments', icon: Sparkles, label: 'Moments' },
  { path: '/settings', icon: Settings, label: 'Settings' },
]

export const BottomNav = () => {
  const location = useLocation()

  return (
    <motion.nav
      className="fixed bottom-0 left-0 right-0 bg-white border-t border-bond-border safe-bottom"
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="max-w-md mx-auto flex justify-around">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex-1 flex flex-col items-center justify-center py-3 px-2 text-xs font-medium transition-all ${
                isActive ? 'text-bond-600' : 'text-bond-text-muted hover:text-bond-text'
              }`}
            >
              <item.icon className={`w-5 h-5 mb-1 ${isActive ? 'fill-current' : ''}`} />
              {item.label}
            </Link>
          )
        })}
      </div>
    </motion.nav>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/common/Button.jsx
import { motion } from 'framer-motion'

export const Button = ({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  disabled,
  full = false,
  ...props
}) => {
  const variants = {
    primary: 'bond-btn-primary',
    ghost: 'bond-btn-ghost',
  }
  const sizes = {
    sm: 'py-2 px-4 text-sm',
    md: 'py-3 px-6 text-base',
    lg: 'py-4 px-8 text-lg',
  }

  return (
    <motion.button
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      onClick={onClick}
      disabled={disabled}
      className={`${variants[variant]} ${sizes[size]} ${full ? 'w-full' : ''} rounded-2xl font-semibold transition-all`}
      {...props}
    >
      {children}
    </motion.button>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/common/Card.jsx
export const Card = ({ children, className = '', ...props }) => {
  return (
    <div className={`bond-card p-4 ${className}`} {...props}>
      {children}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/common/PersonCard.jsx
import { motion } from 'framer-motion'

export const PersonCard = ({ person, onClick, action }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="bond-card p-4 cursor-pointer text-center"
    >
      <img
        src={person.avatar_url || '/placeholder.jpg'}
        alt={person.name}
        className="w-16 h-16 rounded-full mx-auto mb-2 object-cover"
      />
      <h3 className="font-semibold text-bond-900">{person.name}</h3>
      <p className="text-xs text-bond-text-muted">@{person.username}</p>
      {person.mood_emoji && <p className="text-2xl mt-1">{person.mood_emoji}</p>}
      {action && <div className="mt-3 text-xs">{action}</div>}
    </motion.div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/common/MoodBadge.jsx
const MOOD_COLORS = {
  happy: 'mood-happy',
  excited: 'mood-excited',
  calm: 'mood-calm',
  okay: 'mood-okay',
  tired: 'mood-tired',
  anxious: 'mood-anxious',
  sad: 'mood-sad',
  needs_support: 'mood-needs_support',
}

export const MoodBadge = ({ mood, emoji }) => {
  return (
    <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-sm font-medium ${MOOD_COLORS[mood] || 'mood-neutral'}`}>
      <span>{emoji || '😐'}</span>
      <span className="capitalize">{mood?.replace('_', ' ')}</span>
    </div>
  )
}
