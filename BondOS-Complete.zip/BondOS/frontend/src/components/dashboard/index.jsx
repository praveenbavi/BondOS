// src/components/dashboard/Dashboard.jsx
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth, useConnections, useReminders } from '@/hooks'
import { Layout, PersonCard, Button } from '@/components/common'
import { motion } from 'framer-motion'
import { Plus, Bell } from 'lucide-react'
import toast from 'react-hot-toast'

export const Dashboard = () => {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { connections, loadConnections } = useConnections()
  const { reminders, loadReminders } = useReminders()
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    if (user) {
      loadConnections(filter === 'all' ? null : filter)
      loadReminders()
    }
  }, [user, filter])

  const filteredConnections = filter === 'all'
    ? connections
    : connections.filter(c => c.connection.connection_type === filter)

  return (
    <Layout
      title="BondOS"
      subtitle={user ? `Good evening, ${user.name.split(' ')[0]}! 👋` : ''}
    >
      <div className="p-4 space-y-6">
        {/* ── Mood status ───────────────────────────────────────────────────────── */}
        <motion.div
          className="bond-card p-6 bg-gradient-to-br from-bond-500 to-bond-700 text-white rounded-3xl"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <p className="text-sm font-medium opacity-90">Current Mood</p>
          <div className="flex items-end gap-3 mt-2">
            <span className="text-5xl">{user?.mood_emoji || '😐'}</span>
            <div>
              <p className="text-sm font-semibold capitalize">{user?.mood || 'neutral'}</p>
              <button
                onClick={() => navigate('/settings')}
                className="text-xs opacity-75 hover:opacity-100 underline mt-1"
              >
                Update mood
              </button>
            </div>
          </div>
        </motion.div>

        {/* ── Active reminders ──────────────────────────────────────────────────── */}
        {reminders.active.length > 0 && (
          <motion.div
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Bell className="w-5 h-5 text-bond-600" />
              <h2 className="font-bold text-bond-900">Active Reminders</h2>
            </div>
            <div className="space-y-2">
              {reminders.active.slice(0, 3).map(reminder => (
                <div key={reminder.id} className="bond-card p-3 border-l-4 border-bond-600">
                  <p className="text-sm font-medium">{reminder.message}</p>
                  <p className="text-xs text-bond-text-muted mt-1">
                    From: {reminder.sender?.name || 'Someone'}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* ── Connections ───────────────────────────────────────────────────────── */}
        <motion.div
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-bond-900">My People</h2>
            <button
              onClick={() => navigate('/connections/add')}
              className="p-2 bg-bond-100 text-bond-600 rounded-lg hover:bg-bond-200 transition"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          {/* Filter buttons */}
          <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
            {['all', 'bestie', 'close_circle', 'family', 'friend'].map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-2 rounded-lg whitespace-nowrap font-medium transition-all ${
                  filter === f
                    ? 'bg-bond-600 text-white'
                    : 'bg-bond-100 text-bond-600 hover:bg-bond-200'
                }`}
              >
                {f === 'all' ? 'All' : f.replace('_', ' ')}
              </button>
            ))}
          </div>

          {/* People grid */}
          {filteredConnections.length > 0 ? (
            <div className="grid grid-cols-3 gap-3">
              {filteredConnections.map(conn => (
                <PersonCard
                  key={conn.user.id}
                  person={conn.user}
                  onClick={() => navigate(`/chat/${conn.user.id}`)}
                  action={
                    <span className="text-xs text-bond-text-muted">
                      {conn.connection.last_interaction
                        ? `Active now`
                        : 'Not yet'}
                    </span>
                  }
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-bond-text-muted text-sm mb-3">No connections yet</p>
              <Button onClick={() => navigate('/connections/add')} variant="ghost">
                Add a friend
              </Button>
            </div>
          )}
        </motion.div>

        {/* ── Quick actions ──────────────────────────────────────────────────────── */}
        <motion.div
          className="grid grid-cols-2 gap-3"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Button
            onClick={() => navigate('/moments')}
            variant="ghost"
            full
            className="border-2 border-bond-200"
          >
            📸 Moments
          </Button>
          <Button
            onClick={() => navigate('/anonymous')}
            variant="ghost"
            full
            className="border-2 border-bond-200"
          >
            🎭 Anonymous
          </Button>
        </motion.div>
      </div>
    </Layout>
  )
}
