// src/components/moments/Moments.jsx
import { useState } from 'react'
import { Layout, Button } from '@/components/common'
import { motion } from 'framer-motion'
import { Plus } from 'lucide-react'

export const Moments = () => {
  const [showCreate, setShowCreate] = useState(false)
  const [caption, setCaption] = useState('')

  const handlePost = async () => {
    // TODO: Implement post creation
    setCaption('')
    setShowCreate(false)
  }

  const moments = [
    { id: 1, user: 'You', caption: 'Beautiful sunset! 🌅', media: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400', likes: 23 },
  ]

  return (
    <Layout title="Moments" subtitle="Share your life">
      <div className="p-4 space-y-4">
        {/* Create button */}
        <motion.button
          onClick={() => setShowCreate(!showCreate)}
          className="w-full bond-btn-primary flex items-center justify-center gap-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Plus className="w-5 h-5" />
          Share Moment
        </motion.button>

        {/* Create form */}
        {showCreate && (
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="bond-card p-4 space-y-3"
          >
            <textarea
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="What's on your mind? 💭"
              className="bond-input h-24 resize-none"
            />
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button onClick={handlePost} full>Share</Button>
            </div>
          </motion.div>
        )}

        {/* Moments feed */}
        <div className="space-y-3">
          {moments.map((moment, i) => (
            <motion.div
              key={moment.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bond-card overflow-hidden"
            >
              {moment.media && (
                <img src={moment.media} alt="moment" className="w-full h-48 object-cover" />
              )}
              <div className="p-4">
                <p className="font-semibold text-bond-900">{moment.user}</p>
                <p className="text-sm text-bond-text mt-2">{moment.caption}</p>
                <div className="flex gap-4 mt-3 pt-3 border-t border-bond-border">
                  <button className="text-xs font-medium text-bond-text-muted hover:text-bond-600 transition">
                    ❤️ {moment.likes}
                  </button>
                  <button className="text-xs font-medium text-bond-text-muted hover:text-bond-600 transition">
                    💬 Comment
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </Layout>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/components/anonymous/Anonymous.jsx
import { useEffect, useState } from 'react'
import { anonymousService } from '@/services'
import { Layout, Button } from '@/components/common'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus } from 'lucide-react'
import toast from 'react-hot-toast'

export const Anonymous = () => {
  const [showCreate, setShowCreate] = useState(false)
  const [content, setContent] = useState('')
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadPosts()
  }, [])

  const loadPosts = async () => {
    setLoading(true)
    try {
      const data = await anonymousService.list({ skip: 0, limit: 50 })
      setPosts(data)
    } catch {
      toast.error('Failed to load posts')
    }
    setLoading(false)
  }

  const handlePost = async () => {
    if (!content.trim()) return
    try {
      const post = await anonymousService.post({ content, visible_to_circle: 'all' })
      setPosts([post, ...posts])
      setContent('')
      setShowCreate(false)
      toast.success('Posted anonymously!')
    } catch (err) {
      toast.error('Failed to post')
    }
  }

  return (
    <Layout title="Anonymous" subtitle="Be your authentic self">
      <div className="p-4 space-y-4">
        {/* Create button */}
        <motion.button
          onClick={() => setShowCreate(!showCreate)}
          className="w-full bond-btn-primary flex items-center justify-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Say Something
        </motion.button>

        {/* Create form */}
        <AnimatePresence>
          {showCreate && (
            <motion.div
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              className="bond-card p-4 space-y-3"
            >
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="What's on your mind? (stays anonymous)"
                className="bond-input h-24 resize-none"
              />
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setShowCreate(false)}>Cancel</Button>
                <Button onClick={handlePost} full disabled={!content.trim()}>Post</Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Posts */}
        <div className="space-y-3">
          {posts.map((post, i) => (
            <motion.div
              key={post.id}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: i * 0.05 }}
              className="bond-card p-4 bg-gradient-to-br from-purple-50 to-indigo-50 border-l-4 border-purple-400"
            >
              <p className="text-sm text-bond-900">{post.content}</p>
              <div className="flex gap-3 mt-3 pt-3 border-t border-purple-200">
                <button className="text-xs font-medium text-purple-600 hover:text-purple-700 transition">
                  ❤️ {post.reaction_count}
                </button>
                <button className="text-xs font-medium text-purple-600 hover:text-purple-700 transition">
                  💬 {post.comment_count}
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        {posts.length === 0 && !loading && (
          <div className="text-center py-8">
            <p className="text-bond-text-muted text-sm">No posts yet. Be the first! 👻</p>
          </div>
        )}
      </div>
    </Layout>
  )
}
