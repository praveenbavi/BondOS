// src/components/pulse/Pulse.jsx
import { useEffect } from 'react'
import { useMood } from '@/hooks'
import { Layout, Card } from '@/components/common'
import { motion } from 'framer-motion'
import { Heart, AlertCircle } from 'lucide-react'

export const Pulse = () => {
  const { pulse, loadPulse } = useMood()

  useEffect(() => {
    loadPulse()
    const interval = setInterval(loadPulse, 10_000)
    return () => clearInterval(interval)
  }, [])

  const stats = [
    { label: 'Good', value: pulse.good, color: 'text-green-500', bg: 'bg-green-50' },
    { label: 'Okay', value: pulse.okay, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { label: 'Needs Support', value: pulse.needs_support, color: 'text-red-500', bg: 'bg-red-50' },
  ]

  return (
    <Layout title="Pulse" subtitle="How are your people doing?">
      <div className="p-4 space-y-6">
        {/* Health stats */}
        <motion.div
          className="grid grid-cols-3 gap-3"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          {stats.map(stat => (
            <Card key={stat.label} className={`text-center ${stat.bg}`}>
              <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
              <p className="text-xs font-medium text-bond-text-muted mt-1">{stat.label}</p>
            </Card>
          ))}
        </motion.div>

        {/* People list */}
        <div>
          <h2 className="font-bold text-bond-900 mb-3">Your Circle</h2>
          <div className="space-y-2">
            {pulse.people.map((person, i) => (
              <motion.div
                key={person.user_id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: i * 0.05 }}
                className="bond-card p-4 flex items-center gap-3"
              >
                <img
                  src={person.avatar_url || '/placeholder.jpg'}
                  alt={person.name}
                  className="w-12 h-12 rounded-full"
                />
                <div className="flex-1">
                  <p className="font-semibold text-bond-900">{person.name}</p>
                  <p className="text-xs text-bond-text-muted">{person.mood}</p>
                </div>
                <span className="text-2xl">{person.mood_emoji}</span>
              </motion.div>
            ))}
          </div>

          {pulse.needs_support > 0 && (
            <motion.div
              className="mt-4 p-4 bg-red-50 border-l-4 border-red-500 rounded-lg flex gap-3"
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-red-900 text-sm">
                  {pulse.needs_support} {pulse.needs_support === 1 ? 'person' : 'people'} might need support
                </p>
                <p className="text-xs text-red-700 mt-1">Consider reaching out with a message or reminder</p>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </Layout>
  )
}
