// src/components/reminders/Reminders.jsx
import { useEffect, useState } from 'react'
import { useReminders } from '@/hooks'
import { Layout, Button } from '@/components/common'
import { motion } from 'framer-motion'
import { Bell, Check, X } from 'lucide-react'
import toast from 'react-hot-toast'

export const Reminders = () => {
  const { reminders, loadReminders, approveReminder, rejectReminder } = useReminders()
  const [activeTab, setActiveTab] = useState('pending')

  useEffect(() => {
    loadReminders()
  }, [])

  const pending = reminders.received?.filter(r => r.status === 'pending') || []
  const approved = reminders.received?.filter(r => r.status === 'approved') || []
  const sent = reminders.sent || []

  const tabs = [
    { id: 'pending', label: 'Pending', count: pending.length },
    { id: 'approved', label: 'Active', count: approved.length },
    { id: 'sent', label: 'Sent', count: sent.length },
  ]

  const renderReminders = () => {
    switch (activeTab) {
      case 'pending':
        return pending
      case 'approved':
        return approved
      case 'sent':
        return sent
      default:
        return []
    }
  }

  const handleApprove = async (reminderId) => {
    await approveReminder(reminderId)
    await loadReminders()
  }

  const handleReject = async (reminderId) => {
    await rejectReminder(reminderId)
    await loadReminders()
  }

  return (
    <Layout title="Reminders" subtitle="Stay connected">
      <div className="p-4 space-y-4">
        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg whitespace-nowrap font-medium transition-all text-sm flex items-center gap-2 ${
                activeTab === tab.id
                  ? 'bg-bond-600 text-white'
                  : 'bg-bond-100 text-bond-600 hover:bg-bond-200'
              }`}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-white/30">
                  {tab.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Reminders list */}
        <div className="space-y-3">
          {renderReminders().length === 0 ? (
            <div className="text-center py-8">
              <Bell className="w-12 h-12 mx-auto opacity-20 mb-3" />
              <p className="text-bond-text-muted text-sm">No {activeTab} reminders</p>
            </div>
          ) : (
            renderReminders().map((reminder, i) => (
              <motion.div
                key={reminder.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: i * 0.05 }}
                className={`bond-card p-4 border-l-4 ${
                  activeTab === 'pending'
                    ? 'border-yellow-400 bg-yellow-50'
                    : activeTab === 'approved'
                    ? 'border-green-400 bg-green-50'
                    : 'border-blue-400 bg-blue-50'
                }`}
              >
                <p className="font-semibold text-bond-900">{reminder.message}</p>
                <p className="text-xs text-bond-text-muted mt-1">
                  {activeTab === 'sent' ? 'Sent to' : 'From'}: Someone
                </p>

                {/* Remind at */}
                {reminder.remind_at && (
                  <p className="text-xs text-bond-text-muted mt-2">
                    ⏰ {new Date(reminder.remind_at).toLocaleString()}
                  </p>
                )}

                {/* Actions */}
                {activeTab === 'pending' && (
                  <div className="flex gap-2 mt-3 pt-3 border-t border-current border-opacity-20">
                    <button
                      onClick={() => handleApprove(reminder.id)}
                      className="flex-1 flex items-center justify-center gap-1 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition text-sm font-medium"
                    >
                      <Check className="w-4 h-4" /> Approve
                    </button>
                    <button
                      onClick={() => handleReject(reminder.id)}
                      className="flex-1 flex items-center justify-center gap-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition text-sm font-medium"
                    >
                      <X className="w-4 h-4" /> Decline
                    </button>
                  </div>
                )}

                {activeTab === 'approved' && (
                  <div className="mt-3 pt-3 border-t border-current border-opacity-20">
                    <p className="text-xs font-medium text-green-700">✓ Approved on {new Date(reminder.approved_at).toLocaleDateString()}</p>
                  </div>
                )}
              </motion.div>
            ))
          )}
        </div>
      </div>
    </Layout>
  )
}
