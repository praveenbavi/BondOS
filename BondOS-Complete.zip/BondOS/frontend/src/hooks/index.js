// src/hooks/useAuth.js
import { useSelector, useDispatch } from 'react-redux'
import { loginStart, loginSuccess, loginFailure, logout } from '@/store/slices/authSlice'
import { authService } from '@/services'
import toast from 'react-hot-toast'

export const useAuth = () => {
  const dispatch = useDispatch()
  const { user, token, isLoading, error } = useSelector(state => state.auth)

  const login = async (email, password) => {
    dispatch(loginStart())
    try {
      const data = await authService.login({ email, password })
      dispatch(loginSuccess(data))
      toast.success('Welcome back!')
      return true
    } catch (err) {
      const msg = err.response?.data?.detail || 'Login failed'
      dispatch(loginFailure(msg))
      toast.error(msg)
      return false
    }
  }

  const register = async (userData) => {
    dispatch(loginStart())
    try {
      const data = await authService.register(userData)
      dispatch(loginSuccess(data))
      toast.success('Account created!')
      return true
    } catch (err) {
      const msg = err.response?.data?.detail || 'Registration failed'
      dispatch(loginFailure(msg))
      toast.error(msg)
      return false
    }
  }

  const logoutUser = () => {
    dispatch(logout())
    toast.success('Logged out')
  }

  return { user, token, isLoading, error, login, register, logoutUser, isLoggedIn: !!token }
}

// ─────────────────────────────────────────────────────────────────────────────
// src/hooks/useConnections.js
import { useDispatch, useSelector } from 'react-redux'
import { setConnections, addConnection } from '@/store/slices/dataSlice'
import { connectionService } from '@/services'
import toast from 'react-hot-toast'

export const useConnections = () => {
  const dispatch = useDispatch()
  const connections = useSelector(state => state.data.connections)

  const loadConnections = async (type) => {
    try {
      const data = await connectionService.list(type)
      dispatch(setConnections(data))
    } catch (err) {
      toast.error('Failed to load connections')
    }
  }

  const addNewConnection = async (userId, connectionType) => {
    try {
      const data = await connectionService.add({
        connected_user_id: userId,
        connection_type: connectionType,
      })
      dispatch(addConnection(data))
      toast.success('Connection request sent!')
      return true
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed')
      return false
    }
  }

  const searchUsers = async (query) => {
    try {
      return await connectionService.searchUsers(query)
    } catch {
      toast.error('Search failed')
      return []
    }
  }

  return { connections, loadConnections, addNewConnection, searchUsers }
}

// ─────────────────────────────────────────────────────────────────────────────
// src/hooks/useMessages.js
import { useDispatch, useSelector } from 'react-redux'
import { setMessages, addMessage, setConversationsList } from '@/store/slices/dataSlice'
import { messageService } from '@/services'
import toast from 'react-hot-toast'

export const useMessages = () => {
  const dispatch = useDispatch()
  const messages = useSelector(state => state.data.messages)
  const conversations = useSelector(state => state.data.conversationsList)

  const loadConversation = async (partnerId) => {
    try {
      const data = await messageService.getConversation(partnerId, { skip: 0, limit: 50 })
      dispatch(setMessages({ partnerId, messages: data }))
    } catch (err) {
      toast.error('Failed to load conversation')
    }
  }

  const loadConversations = async () => {
    try {
      const data = await messageService.getConversations()
      dispatch(setConversationsList(data))
    } catch (err) {
      toast.error('Failed to load conversations')
    }
  }

  const sendMessage = async (receiverId, content, messageType = 'text') => {
    try {
      const data = await messageService.send({
        receiver_id: receiverId,
        content,
        message_type: messageType,
      })
      dispatch(addMessage({ partnerId: receiverId, message: data }))
      return true
    } catch (err) {
      toast.error('Failed to send message')
      return false
    }
  }

  return { messages, conversations, loadConversation, loadConversations, sendMessage }
}

// ─────────────────────────────────────────────────────────────────────────────
// src/hooks/useReminders.js
import { useDispatch, useSelector } from 'react-redux'
import { setReminders, updateReminderStatus } from '@/store/slices/dataSlice'
import { reminderService } from '@/services'
import toast from 'react-hot-toast'

export const useReminders = () => {
  const dispatch = useDispatch()
  const reminders = useSelector(state => state.data.reminders)

  const loadReminders = async () => {
    try {
      const [sent, received, active] = await Promise.all([
        reminderService.sent({ skip: 0, limit: 20 }),
        reminderService.received({ skip: 0, limit: 20 }),
        reminderService.active(),
      ])
      dispatch(setReminders({ sent, received, active }))
    } catch (err) {
      toast.error('Failed to load reminders')
    }
  }

  const sendReminder = async (receiverId, message, reminderType = 'soft') => {
    try {
      await reminderService.send({
        receiver_id: receiverId,
        message,
        reminder_type: reminderType,
      })
      toast.success('Reminder sent!')
      await loadReminders()
      return true
    } catch (err) {
      toast.error('Failed to send reminder')
      return false
    }
  }

  const approveReminder = async (reminderId) => {
    try {
      await reminderService.approve(reminderId)
      dispatch(updateReminderStatus({ id: reminderId, status: 'approved' }))
      toast.success('Reminder approved!')
      return true
    } catch (err) {
      toast.error('Failed')
      return false
    }
  }

  const rejectReminder = async (reminderId) => {
    try {
      await reminderService.reject(reminderId)
      dispatch(updateReminderStatus({ id: reminderId, status: 'rejected' }))
      toast.success('Reminder rejected')
      return true
    } catch (err) {
      toast.error('Failed')
      return false
    }
  }

  return { reminders, loadReminders, sendReminder, approveReminder, rejectReminder }
}

// ─────────────────────────────────────────────────────────────────────────────
// src/hooks/useMood.js
import { useDispatch, useSelector } from 'react-redux'
import { addMood, setPulse } from '@/store/slices/dataSlice'
import { moodService, pulseService } from '@/services'
import toast from 'react-hot-toast'

export const useMood = () => {
  const dispatch = useDispatch()
  const pulse = useSelector(state => state.data.pulse)

  const setMood = async (mood, emoji, note, visibleTo = 'close_circle') => {
    try {
      const data = await moodService.set({ mood, emoji, note, visible_to: visibleTo })
      dispatch(addMood(data))
      toast.success('Mood updated!')
      return true
    } catch (err) {
      toast.error('Failed to update mood')
      return false
    }
  }

  const loadPulse = async () => {
    try {
      const data = await pulseService.get()
      dispatch(setPulse(data))
    } catch (err) {
      toast.error('Failed to load pulse')
    }
  }

  return { pulse, setMood, loadPulse }
}
