// src/pages/Login.jsx
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks'
import { Button } from '@/components/common'
import { motion } from 'framer-motion'

export const Login = () => {
  const navigate = useNavigate()
  const { login, isLoading, isLoggedIn } = useAuth()
  const [formData, setFormData] = useState({ email: '', password: '' })

  useEffect(() => {
    if (isLoggedIn) navigate('/dashboard')
  }, [isLoggedIn])

  const handleSubmit = async (e) => {
    e.preventDefault()
    const success = await login(formData.email, formData.password)
    if (success) navigate('/dashboard')
  }

  return (
    <div className="min-h-dvh bg-gradient-to-br from-bond-600 to-bond-900 flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">BondOS</h1>
          <p className="text-bond-100">Your Relationship Operating System</p>
        </div>

        <div className="bond-card p-8 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="you@example.com"
                className="bond-input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Password</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••"
                className="bond-input"
                required
              />
            </div>
            <Button
              type="submit"
              disabled={isLoading}
              full
            >
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-bond-border"></div></div>
            <div className="relative flex justify-center text-sm"><span className="px-2 bg-white text-bond-text-muted">or</span></div>
          </div>

          <button
            onClick={() => navigate('/register')}
            className="w-full py-3 border-2 border-bond-200 rounded-2xl font-semibold text-bond-600 hover:bg-bond-50 transition"
          >
            Create Account
          </button>
        </div>
      </motion.div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// src/pages/Register.jsx
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks'
import { Button } from '@/components/common'
import { motion } from 'framer-motion'

export const Register = () => {
  const navigate = useNavigate()
  const { register, isLoading, isLoggedIn } = useAuth()
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  })

  useEffect(() => {
    if (isLoggedIn) navigate('/dashboard')
  }, [isLoggedIn])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match')
      return
    }
    const success = await register({
      name: formData.name,
      username: formData.username,
      email: formData.email,
      password: formData.password,
    })
    if (success) navigate('/dashboard')
  }

  return (
    <div className="min-h-dvh bg-gradient-to-br from-bond-600 to-bond-900 flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Join BondOS</h1>
          <p className="text-bond-100">Create your relationship OS</p>
        </div>

        <div className="bond-card p-8 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="John Doe"
                className="bond-input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Username</label>
              <input
                type="text"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                placeholder="johndoe"
                className="bond-input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="you@example.com"
                className="bond-input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Password</label>
              <input
                type="password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••"
                className="bond-input"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-bond-900 mb-2">Confirm Password</label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                placeholder="••••••••"
                className="bond-input"
                required
              />
            </div>
            <Button type="submit" disabled={isLoading} full>
              {isLoading ? 'Creating account...' : 'Create Account'}
            </Button>
          </form>

          <div className="text-center">
            <p className="text-sm text-bond-text-muted">
              Already have an account?{' '}
              <button
                onClick={() => navigate('/login')}
                className="text-bond-600 font-semibold hover:text-bond-700"
              >
                Sign in
              </button>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
