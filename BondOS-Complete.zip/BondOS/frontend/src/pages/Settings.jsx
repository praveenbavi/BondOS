// src/pages/Settings.jsx
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth, useMood } from '@/hooks'
import { Layout, Button, MoodBadge } from '@/components/common'
import { motion } from 'framer-motion'
import { LogOut } from 'lucide-react'
import toast from 'react-hot-toast'

const MOODS = [
  { name: 'happy', emoji: '😊' },
  { name: 'excited', emoji: '🤩' },
  { name: 'calm', emoji: '😌' },
  { name: 'okay', emoji: '😐' },
  { name: 'tired', emoji: '😴' },
  { name: 'anxious', emoji: '😰' },
  { name: 'sad', emoji: '😢' },
  { name: 'needs_support', emoji: '🆘' },
]

export const Settings = () => {
  const navigate = useNavigate()
  const { user, logoutUser } = useAuth()
  const { setMood } = useMood()
  const [selectedMood, setSelectedMood] = useState(user?.mood || 'okay')
  const [visibleTo, setVisibleTo] = useState('close_circle')

  const handleMoodUpdate = async (mood) => {
    const moodObj = MOODS.find(m => m.name === mood)
    await setMood(mood, moodObj.emoji, '', visibleTo)
    setSelectedMood(mood)
  }

  const handleLogout = () => {
    logoutUser()
    navigate('/login')
  }

  return (
    <Layout title="Settings" subtitle="Manage your profile">
      <div className="p-4 space-y-6">
        {/* Profile card */}
        <motion.div
          className="bond-card p-6 text-center"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <img
            src={user?.avatar_url || '/placeholder.jpg'}
            alt={user?.name}
            className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
          />
          <h2 className="text-2xl font-bold text-bond-900">{user?.name}</h2>
          <p className="text-sm text-bond-text-muted">@{user?.username}</p>
          {user?.bio && <p className="text-sm text-bond-text mt-2">{user.bio}</p>}
        </motion.div>

        {/* Mood selector */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="font-bold text-bond-900 mb-3">How are you feeling?</h3>
          <div className="grid grid-cols-4 gap-2">
            {MOODS.map(mood => (
              <button
                key={mood.name}
                onClick={() => handleMoodUpdate(mood.name)}
                className={`p-3 rounded-2xl text-2xl transition-all ${
                  selectedMood === mood.name
                    ? 'ring-2 ring-bond-600 scale-110'
                    : 'hover:scale-105'
                }`}
              >
                {mood.emoji}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Visibility setting */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bond-card p-4"
        >
          <label className="text-sm font-semibold text-bond-900 mb-3 block">Mood visible to</label>
          <select
            value={visibleTo}
            onChange={(e) => setVisibleTo(e.target.value)}
            className="bond-input"
          >
            <option value="close_circle">Close Circle</option>
            <option value="family">Family</option>
            <option value="all">Everyone</option>
          </select>
        </motion.div>

        {/* App settings */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="space-y-2"
        >
          <h3 className="font-bold text-bond-900 mb-3">Preferences</h3>
          {[
            { label: 'Notifications', enabled: true },
            { label: 'Location Sharing', enabled: user?.location_sharing },
            { label: 'Quiet Mode', enabled: user?.is_quiet_mode },
          ].map(pref => (
            <div key={pref.label} className="bond-card p-4 flex items-center justify-between">
              <span className="font-medium text-bond-900">{pref.label}</span>
              <button className={`w-12 h-6 rounded-full transition-all ${pref.enabled ? 'bg-green-500' : 'bg-gray-300'}`} />
            </div>
          ))}
        </motion.div>

        {/* Logout */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Button
            onClick={handleLogout}
            variant="ghost"
            full
            className="border-2 border-red-200 text-red-600 flex items-center justify-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </Button>
        </motion.div>

        {/* About */}
        <div className="text-center py-4 border-t border-bond-border">
          <p className="text-xs text-bond-text-muted">BondOS v1.0.0</p>
          <p className="text-xs text-bond-text-muted">Built with 💙 for human connection</p>
        </div>
      </div>
    </Layout>
  )
}
