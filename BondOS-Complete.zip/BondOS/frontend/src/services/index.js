// src/services/authService.js
import api from './api'

export const authService = {
  register: (data) => api.post('/auth/register', data).then(r => r.data),
  login:    (data) => api.post('/auth/login', data).then(r => r.data),
  me:       ()     => api.get('/auth/me').then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/connectionService.js
export const connectionService = {
  list:         (type) => api.get('/connections', { params: type ? { connection_type: type } : {} }).then(r => r.data),
  add:          (data) => api.post('/connections', data).then(r => r.data),
  accept:       (id)   => api.post(`/connections/${id}/accept`).then(r => r.data),
  searchUsers:  (q)    => api.get('/users/search', { params: { q } }).then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/reminderService.js
export const reminderService = {
  send:     (data) => api.post('/reminders', data).then(r => r.data),
  approve:  (id)   => api.post(`/reminders/${id}/approve`).then(r => r.data),
  reject:   (id)   => api.post(`/reminders/${id}/reject`).then(r => r.data),
  complete: (id)   => api.post(`/reminders/${id}/complete`).then(r => r.data),
  sent:     (p)    => api.get('/reminders/sent', { params: p }).then(r => r.data),
  received: (p)    => api.get('/reminders/received', { params: p }).then(r => r.data),
  active:   ()     => api.get('/reminders/active').then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/messageService.js
export const messageService = {
  send:             (data)      => api.post('/messages', data).then(r => r.data),
  getConversation:  (id, p)     => api.get(`/messages/conversation/${id}`, { params: p }).then(r => r.data),
  getConversations: ()          => api.get('/messages/list').then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/moodService.js
export const moodService = {
  set:     (data) => api.post('/moods', data).then(r => r.data),
  history: (p)    => api.get('/moods/history', { params: p }).then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/pulseService.js
export const pulseService = {
  get: () => api.get('/pulse').then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/postService.js
export const postService = {
  create: (data) => api.post('/posts', data).then(r => r.data),
  feed:   (p)    => api.get('/posts', { params: p }).then(r => r.data),
  react:  (id, emoji) => api.post(`/posts/${id}/react`, null, { params: { emoji } }).then(r => r.data),
}

// ─────────────────────────────────────────────────────────────────────────────
// src/services/anonymousService.js
export const anonymousService = {
  post:   (data) => api.post('/anonymous', data).then(r => r.data),
  list:   (p)    => api.get('/anonymous', { params: p }).then(r => r.data),
  react:  (id, emoji) => api.post(`/anonymous/${id}/react`, null, { params: { emoji } }).then(r => r.data),
}
