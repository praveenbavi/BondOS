// src/services/websocketService.js
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws'

class WebSocketService {
  constructor() {
    this.socket = null
    this.listeners = {}
    this.reconnectAttempts = 0
    this.maxReconnects = 5
    this.reconnectDelay = 2000
  }

  connect(token) {
    if (this.socket?.readyState === WebSocket.OPEN) return

    this.socket = new WebSocket(`${WS_URL}?token=${token}`)

    this.socket.onopen = () => {
      console.log('[WS] Connected')
      this.reconnectAttempts = 0
      this._startHeartbeat()
    }

    this.socket.onmessage = (evt) => {
      try {
        const { event, data } = JSON.parse(evt.data)
        this._emit(event, data)
      } catch {}
    }

    this.socket.onclose = () => {
      console.log('[WS] Disconnected')
      this._stopHeartbeat()
      this._scheduleReconnect(token)
    }

    this.socket.onerror = (err) => {
      console.error('[WS] Error', err)
    }
  }

  disconnect() {
    this._stopHeartbeat()
    this.socket?.close()
    this.socket = null
  }

  send(event, data) {
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({ event, data }))
    }
  }

  on(event, handler) {
    if (!this.listeners[event]) this.listeners[event] = []
    this.listeners[event].push(handler)
    return () => this.off(event, handler)
  }

  off(event, handler) {
    this.listeners[event] = (this.listeners[event] || []).filter(h => h !== handler)
  }

  _emit(event, data) {
    ;(this.listeners[event] || []).forEach(h => h(data))
  }

  _startHeartbeat() {
    this._heartbeatTimer = setInterval(() => this.send('ping', {}), 25_000)
  }

  _stopHeartbeat() {
    clearInterval(this._heartbeatTimer)
  }

  _scheduleReconnect(token) {
    if (this.reconnectAttempts >= this.maxReconnects) return
    this.reconnectAttempts++
    setTimeout(() => this.connect(token), this.reconnectDelay * this.reconnectAttempts)
  }
}

export const wsService = new WebSocketService()
export default wsService
