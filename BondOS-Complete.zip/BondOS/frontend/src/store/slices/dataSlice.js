// src/store/slices/dataSlice.js
import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  connections: [],
  messages: {},
  conversationsList: [],
  reminders: { sent: [], received: [], active: [] },
  moods: [],
  pulse: { good: 0, okay: 0, needs_support: 0, total: 0, people: [] },
  posts: [],
  anonymousPosts: [],
  currentChat: null,
  isLoading: false,
  error: null,
}

const dataSlice = createSlice({
  name: 'data',
  initialState,
  reducers: {
    setConnections: (state, action) => {
      state.connections = action.payload
    },
    addConnection: (state, action) => {
      state.connections.push(action.payload)
    },
    setMessages: (state, action) => {
      const { partnerId, messages } = action.payload
      state.messages[partnerId] = messages
    },
    addMessage: (state, action) => {
      const { partnerId, message } = action.payload
      if (!state.messages[partnerId]) state.messages[partnerId] = []
      state.messages[partnerId].push(message)
    },
    setConversationsList: (state, action) => {
      state.conversationsList = action.payload
    },
    setReminders: (state, action) => {
      state.reminders = action.payload
    },
    updateReminderStatus: (state, action) => {
      const { id, status } = action.payload
      const reminder = [
        ...state.reminders.sent,
        ...state.reminders.received,
        ...state.reminders.active,
      ].find(r => r.id === id)
      if (reminder) reminder.status = status
    },
    setMoods: (state, action) => {
      state.moods = action.payload
    },
    addMood: (state, action) => {
      state.moods.unshift(action.payload)
    },
    setPulse: (state, action) => {
      state.pulse = action.payload
    },
    setPosts: (state, action) => {
      state.posts = action.payload
    },
    addPost: (state, action) => {
      state.posts.unshift(action.payload)
    },
    setAnonymousPosts: (state, action) => {
      state.anonymousPosts = action.payload
    },
    addAnonymousPost: (state, action) => {
      state.anonymousPosts.unshift(action.payload)
    },
    setCurrentChat: (state, action) => {
      state.currentChat = action.payload
    },
    setLoading: (state, action) => {
      state.isLoading = action.payload
    },
    setError: (state, action) => {
      state.error = action.payload
    },
  },
})

export const {
  setConnections, addConnection,
  setMessages, addMessage, setConversationsList,
  setReminders, updateReminderStatus,
  setMoods, addMood,
  setPulse,
  setPosts, addPost,
  setAnonymousPosts, addAnonymousPost,
  setCurrentChat,
  setLoading, setError,
} = dataSlice.actions

export default dataSlice.reducer
