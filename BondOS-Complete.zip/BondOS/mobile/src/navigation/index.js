// mobile/src/navigation/RootNavigator.js
import React from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { useAuth } from '@/hooks'

import { LoginScreen } from '@/screens/auth/LoginScreen'
import { RegisterScreen } from '@/screens/auth/RegisterScreen'
import { DashboardScreen } from '@/screens/DashboardScreen'
import { ChatListScreen } from '@/screens/ChatListScreen'
import { ChatDetailScreen } from '@/screens/ChatDetailScreen'
import { PulseScreen } from '@/screens/PulseScreen'
import { MomentsScreen } from '@/screens/MomentsScreen'
import { AnonymousScreen } from '@/screens/AnonymousScreen'
import { SettingsScreen } from '@/screens/SettingsScreen'

const Stack = createNativeStackNavigator()
const Tab = createBottomTabNavigator()

const DashboardStack = () => (
  <Stack.Navigator
    screenOptions={{ headerShown: false, animationEnabled: true }}
  >
    <Stack.Screen name="DashboardHome" component={DashboardScreen} />
    <Stack.Screen name="ChatList" component={ChatListScreen} />
    <Stack.Screen name="ChatDetail" component={ChatDetailScreen} />
  </Stack.Navigator>
)

const AuthStack = () => (
  <Stack.Navigator
    screenOptions={{ headerShown: false, cardStyle: { backgroundColor: '#fff' } }}
  >
    <Stack.Screen name="Login" component={LoginScreen} />
    <Stack.Screen name="Register" component={RegisterScreen} />
  </Stack.Navigator>
)

const AppTabs = () => (
  <Tab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: '#6477f8',
      tabBarInactiveTintColor: '#6b7280',
      tabBarStyle: {
        backgroundColor: '#fff',
        borderTopColor: '#e5e7f0',
        borderTopWidth: 1,
        paddingBottom: 8,
      },
    }}
  >
    <Tab.Screen
      name="Dashboard"
      component={DashboardStack}
      options={{ title: 'Home', tabBarLabel: 'Home' }}
    />
    <Tab.Screen
      name="Pulse"
      component={PulseScreen}
      options={{ title: 'Pulse', tabBarLabel: 'Pulse' }}
    />
    <Tab.Screen
      name="Chat"
      component={ChatListScreen}
      options={{ title: 'Chat', tabBarLabel: 'Chat' }}
    />
    <Tab.Screen
      name="Moments"
      component={MomentsScreen}
      options={{ title: 'Moments', tabBarLabel: 'Moments' }}
    />
    <Tab.Screen
      name="Settings"
      component={SettingsScreen}
      options={{ title: 'Settings', tabBarLabel: 'Settings' }}
    />
  </Tab.Navigator>
)

export const RootNavigator = () => {
  const { isLoggedIn } = useAuth()

  return (
    <NavigationContainer>
      {isLoggedIn ? <AppTabs /> : <AuthStack />}
    </NavigationContainer>
  )
}
