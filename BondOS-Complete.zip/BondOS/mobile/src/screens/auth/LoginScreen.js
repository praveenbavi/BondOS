// mobile/src/screens/auth/LoginScreen.js
import React, { useState } from 'react'
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
} from 'react-native'
import { useAuth } from '@/hooks'

export const LoginScreen = ({ navigation }) => {
  const { login, isLoading } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleLogin = async () => {
    const success = await login(email, password)
    if (success) {
      navigation.replace('Dashboard')
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>BondOS</Text>
          <Text style={styles.subtitle}>Your Relationship OS</Text>
        </View>

        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              placeholder="you@example.com"
              value={email}
              onChangeText={setEmail}
              editable={!isLoading}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              placeholder="••••••••"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!isLoading}
            />
          </View>

          <TouchableOpacity
            style={[styles.button, styles.primaryButton, isLoading && styles.disabled]}
            onPress={handleLogin}
            disabled={isLoading}
          >
            <Text style={styles.buttonText}>
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.link}>Don't have an account? <Text style={styles.linkBold}>Sign up</Text></Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

// mobile/src/screens/auth/RegisterScreen.js
export const RegisterScreen = ({ navigation }) => {
  const { register, isLoading } = useAuth()
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  })

  const handleRegister = async () => {
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match')
      return
    }
    const success = await register({
      name: formData.name,
      username: formData.username,
      email: formData.email,
      password: formData.password,
    })
    if (success) {
      navigation.replace('Dashboard')
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>Join BondOS</Text>
          <Text style={styles.subtitle}>Create your relationship OS</Text>
        </View>

        <View style={styles.form}>
          {[
            { label: 'Name', key: 'name', placeholder: 'John Doe' },
            { label: 'Username', key: 'username', placeholder: 'johndoe' },
            { label: 'Email', key: 'email', placeholder: 'you@example.com', keyboardType: 'email-address' },
            { label: 'Password', key: 'password', placeholder: '••••••••', secureTextEntry: true },
            { label: 'Confirm Password', key: 'confirmPassword', placeholder: '••••••••', secureTextEntry: true },
          ].map(field => (
            <View key={field.key} style={styles.inputGroup}>
              <Text style={styles.label}>{field.label}</Text>
              <TextInput
                style={styles.input}
                placeholder={field.placeholder}
                value={formData[field.key]}
                onChangeText={(val) => setFormData({ ...formData, [field.key]: val })}
                secureTextEntry={field.secureTextEntry}
                editable={!isLoading}
                keyboardType={field.keyboardType}
                autoCapitalize="none"
              />
            </View>
          ))}

          <TouchableOpacity
            style={[styles.button, styles.primaryButton, isLoading && styles.disabled]}
            onPress={handleRegister}
            disabled={isLoading}
          >
            <Text style={styles.buttonText}>
              {isLoading ? 'Creating...' : 'Create Account'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Login')}>
            <Text style={styles.link}>Already have account? <Text style={styles.linkBold}>Sign in</Text></Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  content: { flexGrow: 1, padding: 24 },
  header: { marginBottom: 40, marginTop: 20 },
  title: { fontSize: 32, fontWeight: '700', color: '#1a1d2e', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#6b7280' },
  form: { gap: 16 },
  inputGroup: { gap: 8 },
  label: { fontSize: 14, fontWeight: '600', color: '#1a1d2e' },
  input: {
    borderWidth: 1,
    borderColor: '#e5e7f0',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
  },
  button: { padding: 16, borderRadius: 12, alignItems: 'center' },
  primaryButton: { backgroundColor: '#6477f8' },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  disabled: { opacity: 0.5 },
  link: { textAlign: 'center', fontSize: 14, color: '#6b7280' },
  linkBold: { fontWeight: '600', color: '#6477f8' },
})
