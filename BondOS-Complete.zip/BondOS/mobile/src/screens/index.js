// mobile/src/screens/DashboardScreen.js
import React, { useEffect } from 'react'
import { View, Text, SafeAreaView, StyleSheet, FlatList, TouchableOpacity } from 'react-native'
import { useAuth, useConnections } from '@/hooks'

export const DashboardScreen = ({ navigation }) => {
  const { user } = useAuth()
  const { connections, loadConnections } = useConnections()

  useEffect(() => {
    loadConnections()
  }, [])

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>BondOS</Text>
        <Text style={styles.greeting}>Hello, {user?.name.split(' ')[0]}! 👋</Text>
      </View>

      <View style={styles.moodCard}>
        <Text style={styles.moodEmoji}>{user?.mood_emoji || '😐'}</Text>
        <Text style={styles.moodLabel}>{user?.mood || 'neutral'}</Text>
      </View>

      <Text style={styles.sectionTitle}>My People</Text>
      <FlatList
        data={connections}
        keyExtractor={(item) => item.user.id.toString()}
        numColumns={3}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.personCard}
            onPress={() => navigation.navigate('ChatList', { userId: item.user.id })}
          >
            <View style={styles.avatar} />
            <Text style={styles.personName} numberOfLines={1}>{item.user.name}</Text>
            <Text style={styles.personMood}>{item.user.mood_emoji}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  )
}

// mobile/src/screens/ChatListScreen.js
export const ChatListScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Messages</Text>
      <Text style={styles.subtitle}>Your conversations will appear here</Text>
    </SafeAreaView>
  )
}

// mobile/src/screens/ChatDetailScreen.js
export const ChatDetailScreen = ({ route }) => {
  const { partnerId } = route.params

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Chat with {partnerId}</Text>
    </SafeAreaView>
  )
}

// mobile/src/screens/PulseScreen.js
export const PulseScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Pulse</Text>
      <Text style={styles.subtitle}>How are your people doing?</Text>
    </SafeAreaView>
  )
}

// mobile/src/screens/MomentsScreen.js
export const MomentsScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Moments</Text>
      <Text style={styles.subtitle}>Share your life</Text>
    </SafeAreaView>
  )
}

// mobile/src/screens/AnonymousScreen.js
export const AnonymousScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Anonymous</Text>
      <Text style={styles.subtitle}>Be your authentic self</Text>
    </SafeAreaView>
  )
}

// mobile/src/screens/SettingsScreen.js
export const SettingsScreen = ({ navigation }) => {
  const { logoutUser } = useAuth()

  const handleLogout = () => {
    logoutUser()
    navigation.replace('Login')
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Settings</Text>
      <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
        <Text style={styles.logoutText}>Sign Out</Text>
      </TouchableOpacity>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f7f8fc', paddingHorizontal: 16 },
  header: { paddingVertical: 16 },
  title: { fontSize: 24, fontWeight: '700', color: '#1a1d2e' },
  greeting: { fontSize: 14, color: '#6b7280', marginTop: 4 },
  subtitle: { fontSize: 14, color: '#6b7280', marginTop: 8 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#1a1d2e', marginVertical: 12 },
  moodCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginVertical: 16,
  },
  moodEmoji: { fontSize: 48, marginBottom: 8 },
  moodLabel: { fontSize: 14, color: '#6b7280' },
  personCard: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 12,
    margin: 6,
    borderRadius: 12,
    alignItems: 'center',
  },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: '#e5e7f0', marginBottom: 8 },
  personName: { fontSize: 12, fontWeight: '600', color: '#1a1d2e', textAlign: 'center' },
  personMood: { fontSize: 20, marginTop: 4 },
  logoutButton: { backgroundColor: '#ef4444', padding: 16, borderRadius: 12, marginTop: 24 },
  logoutText: { color: '#fff', fontWeight: '600', textAlign: 'center' },
})
