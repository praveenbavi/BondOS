// mobile/src/store/store.js
import { configureStore } from '@reduxjs/toolkit'
import authReducer from './slices/authSlice'
import dataReducer from './slices/dataSlice'

export const store = configureStore({
  reducer: {
    auth: authReducer,
    data: dataReducer,
  },
})

export default store

// mobile/src/store/slices/authSlice.js
import { createSlice } from '@reduxjs/toolkit'
import AsyncStorage from '@react-native-async-storage/async-storage'

const initialState = {
  user: null,
  token: null,
  isLoading: false,
  error: null,
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    loginStart: (state) => { state.isLoading = true; state.error = null },
    loginSuccess: (state, action) => {
      state.isLoading = false
      state.user = action.payload.user
      state.token = action.payload.access_token
      AsyncStorage.setItem('bonidos_token', action.payload.access_token)
    },
    loginFailure: (state, action) => { state.isLoading = false; state.error = action.payload },
    logout: (state) => {
      state.user = null
      state.token = null
      state.error = null
      AsyncStorage.removeItem('bonidos_token')
    },
    setUser: (state, action) => { state.user = action.payload },
  },
})

export const { loginStart, loginSuccess, loginFailure, logout, setUser } = authSlice.actions
export default authSlice.reducer

// mobile/src/store/slices/dataSlice.js
import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  connections: [],
  messages: {},
  conversationsList: [],
  reminders: { sent: [], received: [], active: [] },
  moods: [],
  pulse: { good: 0, okay: 0, needs_support: 0, total: 0, people: [] },
}

const dataSlice = createSlice({
  name: 'data',
  initialState,
  reducers: {
    setConnections: (state, action) => { state.connections = action.payload },
    setMessages: (state, action) => {
      const { partnerId, messages } = action.payload
      state.messages[partnerId] = messages
    },
    setReminders: (state, action) => { state.reminders = action.payload },
    setMoods: (state, action) => { state.moods = action.payload },
    setPulse: (state, action) => { state.pulse = action.payload },
  },
})

export const { setConnections, setMessages, setReminders, setMoods, setPulse } = dataSlice.actions
export default dataSlice.reducer
